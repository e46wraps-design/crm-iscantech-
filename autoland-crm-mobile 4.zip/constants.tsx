
import React from 'react';
import type { Ticket, LoanerTool, Customer, Tool, User, Sound } from './types';
import { Module, Status, Brand, LoanerToolStatus } from './types';

// FIX: Add and export the Icons object to be used across the application.
export const Icons = {
  plus: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
    </svg>
  ),
  filter: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
    </svg>
  ),
  search: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  ),
  user: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  ),
  ticket: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 00-2-2H5z" />
    </svg>
  ),
  userCircle: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  clock: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  dashboard: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
    </svg>
  ),
  accounts: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  vehicle: (
     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h6m-6 4h6m-6 4h6" />
    </svg>
  ),
  cases: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
    </svg>
  ),
  reports: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
  settings: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  phone: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
    </svg>
  ),
  email: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
  ),
  chat: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  ),
  desktop: (
     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
  ),
  lock: (
     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
  ),
  paperclip: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
    </svg>
  ),
  checkCircle: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  questionMarkCircle: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.546-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
};

export const MODULES = [
  { id: Module.SOD, label: 'SOD' },
  { id: Module.TOOL_REPAIR, label: 'Tool Repair' },
  { id: Module.BUG_REPORTS, label: 'Bug Reports' },
  { id: Module.LOANER_TOOLS, label: 'Loaner Tools' },
  { id: Module.SALES_LEADS, label: 'Sales/Leads' }
];

export const STATUSES = [
  { id: Status.NEW, label: 'New' },
  { id: Status.IN_PROGRESS, label: 'In Progress' },
  { id: Status.CALLBACK_NO_VM, label: 'Callback no voicemail' },
  { id: Status.CALL_COMPLETED, label: 'Call completed' },
  { id: Status.AWAITING_REPLY, label: 'Awaiting Reply' }
];

export const BRANDS = [
    { id: Brand.ACURA, label: 'Acura' },
    { id: Brand.ALFA_ROMEO, label: 'Alfa Romeo' },
    { id: Brand.AUDI, label: 'Audi' },
    { id: Brand.BMW, label: 'BMW' },
    { id: Brand.BUICK, label: 'Buick' },
    { id: Brand.CADILLAC, label: 'Cadillac' },
    { id: Brand.CHEVROLET, label: 'Chevrolet' },
    { id: Brand.CHRYSLER, label: 'Chrysler' },
    { id: Brand.DODGE, label: 'Dodge' },
    { id: Brand.FIAT, label: 'Fiat' },
    { id: Brand.FORD, label: 'Ford' },
    { id: Brand.GMC, label: 'GMC' },
    { id: Brand.HONDA, label: 'Honda' },
    { id: Brand.HYUNDAI, label: 'Hyundai' },
    { id: Brand.INFINITI, label: 'Infiniti' },
    { id: Brand.JAGUAR, label: 'Jaguar' },
    { id: Brand.KIA, label: 'Kia' },
    { id: Brand.LAND_ROVER, label: 'Land Rover' },
    { id: Brand.LEXUS, label: 'Lexus' },
    { id: Brand.LINCOLN, label: 'Lincoln' },
    { id: Brand.MAZDA, label: 'Mazda' },
    { id: Brand.MERCEDES, label: 'Mercedes-Benz' },
    { id: Brand.MINI, label: 'Mini' },
    { id: Brand.MITSUBISHI, label: 'Mitsubishi' },
    { id: Brand.NISSAN, label: 'Nissan' },
    { id: Brand.PORSCHE, label: 'Porsche' },
    { id: Brand.RAM, label: 'Ram' },
    { id: Brand.SUBARU, label: 'Subaru' },
    { id: Brand.TESLA, label: 'Tesla' },
    { id: Brand.TOYOTA, label: 'Toyota' },
    { id: Brand.VOLKSWAGEN, label: 'Volkswagen' },
    { id: Brand.VOLVO, label: 'Volvo' }
];

export const MOCK_USERS: User[] = [
    { id: 'user-1', name: 'Michael Lavandera', email: 'michael.l@autoland.com', avatarUrl: 'https://i.pravatar.cc/40?u=user-1', role: 'admin' },
    { id: 'user-2', name: 'Namtran', email: 'namtran.d@autoland.com', avatarUrl: 'https://i.pravatar.cc/40?u=user-2', role: 'tech' },
    { id: 'user-3', name: 'Tech Support', email: 'support@autoland.com', avatarUrl: 'https://i.pravatar.cc/40?u=user-3', role: 'tech' },
    { id: 'user-4', name: 'Engineering', email: 'engineering@autoland.com', avatarUrl: 'https://i.pravatar.cc/40?u=user-4', role: 'tech' },
];

export const CURRENT_USER: User = MOCK_USERS[0]; // Simulate Michael Lavandera as logged in user

export const MOCK_CUSTOMERS: Customer[] = [
    { id: 'CUST-001', name: 'Janet Putterbaugh', company: 'JP Auto Repair', email: 'janet.p@jpauto.com', phone: '555-0101', address: '123 Auto Row, Mechanicville, USA', subscriptionStatus: 'Active', liveStatus: 'Online' },
    { id: 'CUST-002', name: 'Mario Kolasinski', company: 'Kolasinski Mercedes', email: 'mario.k@merc-specialists.com', phone: '555-0102', address: '456 German Engineering Blvd, Stuttgart, USA', subscriptionStatus: 'Expired', liveStatus: 'Offline' },
    { id: 'CUST-003', name: 'Topvika', company: 'Topvika Diagnostics', email: 'contact@topvika.com', phone: '555-0103', address: '789 Scan Tool Rd, Techtown, USA', subscriptionStatus: 'Trial', liveStatus: 'Away' },
    { id: 'CUST-004', name: 'Namtran', company: 'In-House Repairs', email: 'namtran@autoland.com', phone: '555-0104', address: '1 Corporate Dr, Autoland HQ, USA', subscriptionStatus: 'Active', liveStatus: 'Online' },
];

export const MOCK_TOOLS: Tool[] = [
    { serialNumber: 'ISCAN-BMW-001', customerId: 'CUST-001', model: 'iSCAN for BMW', purchaseDate: '2023-05-20T00:00:00Z', warrantyEndDate: '2025-05-20T00:00:00Z' },
    { serialNumber: 'ISCAN-MB-002', customerId: 'CUST-002', model: 'iSCAN for Mercedes', purchaseDate: '2022-11-10T00:00:00Z', warrantyEndDate: '2024-11-10T00:00:00Z' },
    { serialNumber: 'ELITEPRO-003', customerId: 'CUST-003', model: 'ElitePro Universal', purchaseDate: '2024-01-15T00:00:00Z', warrantyEndDate: '2026-01-15T00:00:00Z' },
    { serialNumber: 'ASSIST001234', customerId: 'CUST-004', model: 'AssistPlus', purchaseDate: '2021-08-01T00:00:00Z', warrantyEndDate: '2023-08-01T00:00:00Z' },
];

const now = new Date();
const yesterday = new Date(now);
yesterday.setDate(now.getDate() - 1);
const twoDaysAgo = new Date(now);
twoDaysAgo.setDate(now.getDate() - 2);
const lastWeek = new Date(now);
lastWeek.setDate(now.getDate() - 7);

export const MOCK_LOANER_TOOLS: LoanerTool[] = [
    { id: 'LT-001', serialNumber: 'ISCAN-SF-1001', type: 'iSCAN SF', status: LoanerToolStatus.IN_USE, assignedTicketId: 'AT-86790-5', purchaseDate: '2023-01-15T00:00:00Z', lastServiceDate: '2024-06-01T00:00:00Z' },
    { id: 'LT-002', serialNumber: 'ISCAN-SF-1002', type: 'iSCAN SF', status: LoanerToolStatus.AVAILABLE, purchaseDate: '2023-01-15T00:00:00Z', lastServiceDate: '2024-06-01T00:00:00Z' },
    { id: 'LT-003', serialNumber: 'PRO-3-2001', type: 'Pro-Series 3', status: LoanerToolStatus.AVAILABLE, purchaseDate: '2022-11-20T00:00:00Z', lastServiceDate: '2024-05-15T00:00:00Z' },
    { id: 'LT-004', serialNumber: 'PRO-3-2002', type: 'Pro-Series 3', status: LoanerToolStatus.IN_REPAIR, purchaseDate: '2022-11-20T00:00:00Z', lastServiceDate: '2024-05-15T00:00:00Z' },
    { id: 'LT-005', serialNumber: 'ASSIST-A-3001', type: 'AssistPlus', status: LoanerToolStatus.AVAILABLE, purchaseDate: '2023-05-10T00:00:00Z', lastServiceDate: '2024-04-20T00:00:00Z' },
    { id: 'LT-006', serialNumber: 'ISCAN-SF-1003', type: 'iSCAN SF', status: LoanerToolStatus.AVAILABLE, purchaseDate: '2023-08-01T00:00:00Z', lastServiceDate: '2024-07-01T00:00:00Z' },
];


export const MOCK_TICKETS: Ticket[] = [
  {
    id: 'AT-86386-3',
    subject: 'BMW Audio System - Asset: Main/Support [US-HQ]',
    requester: 'Janet Putterbaugh',
    customerId: 'CUST-001',
    toolSerialNumber: 'ISCAN-BMW-001',
    module: Module.SOD,
    status: Status.CALL_COMPLETED,
    timestamp: '06/17/2024 16:03 (2 minutes ago)',
    createdAt: new Date().toISOString(),
    dueDate: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000).toISOString(), // Due in 2 days
    symptom: 'No sound and red light on amp.',
    response: 'Tp finds no error codes present; sound is now working. Possibly intermittent.',
    attachments: [{ name: 'bmw_audio_scan.pdf', url: '#' }],
    assignee: "Michael Lavandera",
    teamViewerId: '123 456 789',
    teamViewerPassword: 'password123',
    privateNotes: 'Customer seemed frustrated on the call. Follow up in a week to check if the issue has returned. Advised them on potential costs if it is a hardware failure outside of warranty.',
    vehicle: {
      vin: 'WBA123456789XYZ',
      tag: 'SCANTOOL1',
      year: 2022,
      make: Brand.BMW,
      model: 'X5',
      mileage: 15000
    },
    updates: [
      { id: 'upd1', author: 'Michael Lavandera', timestamp: '06/17/2024 16:05 (about 20 hours ago)', content: 'Initial diagnosis shows no fault codes. Will try to replicate the issue.' },
      { id: 'upd2', author: 'Janet Putterbaugh', timestamp: '06/17/2024 17:30 (about 18 hours ago)', content: 'The sound came back on its own after a restart. Customer is monitoring.' },
      { id: 'upd3', author: 'Michael Lavandera', timestamp: '06/18/2024 09:00 (about 2 hours ago)', content: 'Closing ticket as Recommended Tp. If issue returns, please open a new case with updated diagnostics.' },
    ],
  },
  {
    id: 'AT-86817-1',
    subject: 'SCN Authorizations USA [DTC] | Sales/Leads - Bengt G. [US-TX]',
    requester: 'Mario Kolasinski',
    customerId: 'CUST-002',
    toolSerialNumber: 'ISCAN-MB-002',
    module: Module.SALES_LEADS,
    status: Status.CALLBACK_NO_VM,
    timestamp: '06/16/2024 11:22 (1 day ago)',
    createdAt: yesterday.toISOString(),
    assignee: 'Tech Support',
    dueDate: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(), // Overdue by 1 day
    callbackScheduledAt: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
    symptom: 'Needs SCN for all modules',
    response: 'I called back the number in the ticket but it went to VM. Left a message. The other numbers listed are invalid. Please provide a good callback number.',
    vehicle: {
      vin: 'WDD123456789XYZ',
      tag: 'DIAGPRO',
      year: 2021,
      make: Brand.MERCEDES,
      model: 'C300',
      mileage: 25000
    },
    updates: [
       { id: 'upd1', author: 'Mario Kolasinski', timestamp: '06/16/2024 11:22', content: 'Needs SCN for all modules.' },
       { id: 'upd2', author: 'Tech Support', timestamp: '06/16/2024 12:00', content: 'Attempted callback, no answer. Left voicemail.' },
    ],
  },
  {
    id: 'AT-86799-2',
    subject: 'Hyundai Sonata Diagnostics - [CENTRAL] Mid-Atlantic/Northeast Bryant [US-HQ]',
    requester: 'Topvika',
    customerId: 'CUST-003',
    toolSerialNumber: 'ELITEPRO-003',
    module: Module.BUG_REPORTS,
    status: Status.AWAITING_REPLY,
    timestamp: '06/15/2024 09:45 (2 days ago)',
    createdAt: twoDaysAgo.toISOString(),
    assignee: 'Engineering',
    response: 'Awaiting engineering to provide a patch for this issue.',
    symptom: 'Scan tool fails to communicate with the BCM on this specific model year.',
    privateNotes: 'Engineering team has replicated the bug. Patch is in development, targeted for the next minor software release.',
    teamViewerId: '987 654 321',
    teamViewerPassword: 'securepassword',
    vehicle: {
      vin: 'KMH123456789XYZ',
      tag: 'ELITEPRO',
      year: 2023,
      make: Brand.HYUNDAI,
      model: 'Sonata',
      mileage: 5000
    },
    updates: [
      { id: 'upd1', author: 'Topvika', timestamp: '06/15/2024 09:45', content: 'Reported bug regarding BCM communication failure on 2023 Sonata.' },
      { id: 'upd2', author: 'Engineering', timestamp: '06/15/2024 14:00', content: 'Bug confirmed. We are working on a software update. ETA is 3-5 business days.' },
    ],
  },
   {
    id: 'AT-86790-5',
    subject: 'Loaner Tool Not Returned - Shop XYZ',
    requester: 'Loaner Dept',
    module: Module.LOANER_TOOLS,
    status: Status.IN_PROGRESS,
    timestamp: '06/12/2024 14:00 (5 days ago)',
    createdAt: lastWeek.toISOString(),
    assignee: 'Michael Lavandera',
    response: 'Multiple attempts to contact shop. No response.',
    symptom: 'Loaner tool #LT-001 due back on 06/10/2024 has not been returned.',
    loanerToolId: 'LT-001',
    updates: [
      { id: 'upd1', author: 'Loaner Dept', timestamp: '06/12/2024 14:00', content: 'Created ticket for overdue loaner tool.' },
    ],
  },
  {
    id: 'A1527A1',
    subject: 'Repair Worksheets, CHANH by Namtran',
    requester: 'IN-House',
    customerId: 'CUST-004',
    toolSerialNumber: 'ASSIST001234',
    module: Module.TOOL_REPAIR,
    status: Status.IN_PROGRESS,
    timestamp: '06/19/2024 10:00',
    createdAt: new Date().toISOString(),
    assignee: 'Namtran',
    symptom: 'The screen on my Pro-Series 3 tool is cracked. Need repair options.',
    toolRepairDetails: {
        program: 'Standard',
        ccServices: 'Standard',
        tool: 'vidas3',
        serialNumber: 'ASSIST001234',
        budgetType: 'Customer Pay',
        onHoldTill: 'N/A',
        distributor: 'Autoland',
        supportContact: 'support@autolandscientech.com',
        billContact: 'billing@autolandscientech.com',
        shipContact: 'shipping@autolandscientech.com',
        caseNotes: 'Customer reported cracked screen.',
        dateSent: '06/18/2024',
        sensorSN: 'SENSOR9876',
        technicianNotes: '',
        partsUsed: [
            { id: 'p1', name: 'Pro-Series 3 LCD Screen', partNumber: 'LCD-PS3-01', quantity: 1, cost: 250.00 },
            { id: 'p2', name: 'Screen Gasket Seal', partNumber: 'GSK-PS3-04', quantity: 1, cost: 15.50 },
        ],
    },
    updates: [
      { id: 'upd1', author: 'Client', timestamp: '06/18/2024 14:00', content: 'Event #1: Initial report of cracked screen. Customer states tool was dropped.' },
      { id: 'upd2', author: 'Namtran', timestamp: '06/18/2024 15:30', content: 'Event #2: Received tool, confirmed screen damage. Ordering replacement screen. ETA 2 business days.' },
    ],
  }
];

export const PREDEFINED_SOUNDS: Sound[] = [
    { name: 'Ting', url: 'data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAA/8wXEUx0gANLAAAAAAAAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//8wXEUx8f83LgAAAAAAAAAAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//8wXEUxAAAAAAAAAAAAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV' },
    { name: 'Chime', url: 'data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAA/8wXEUx8gANLAAAAAAAAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//8wXEUx8f83LgAAAAAAAAAAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV' },
    { name: 'Alert', url: 'data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAA/8wXEUx8gANLAAAAAAAAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV' },
    { name: 'Boop', url: 'data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAA/8wXEUx8gANLAAAAAAAAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//8wXEUx8f83LgAAAAAAAAAAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV-` },
];