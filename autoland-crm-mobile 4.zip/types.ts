export enum Module {
  SOD = 'SOD',
  TOOL_REPAIR = 'Tool Repair',
  BUG_REPORTS = 'Bug Reports',
  LOANER_TOOLS = 'Loaner Tools',
  SALES_LEADS = 'Sales/Leads'
}

export enum Status {
  NEW = 'New',
  IN_PROGRESS = 'In Progress',
  CALLBACK_NO_VM = 'Callback no voicemail',
  CALL_COMPLETED = 'Call completed',
  AWAITING_REPLY = 'Awaiting Reply'
}

export enum Brand {
  ACURA = 'Acura',
  ALFA_ROMEO = 'Alfa Romeo',
  AUDI = 'Audi',
  BMW = 'BMW',
  BUICK = 'Buick',
  CADILLAC = 'Cadillac',
  CHEVROLET = 'Chevrolet',
  CHRYSLER = 'Chrysler',
  DODGE = 'Dodge',
  FIAT = 'Fiat',
  FORD = 'Ford',
  GMC = 'GMC',
  HONDA = 'Honda',
  HYUNDAI = 'Hyundai',
  INFINITI = 'Infiniti',
  JAGUAR = 'Jaguar',
  KIA = 'Kia',
  LAND_ROVER = 'Land Rover',
  LEXUS = 'Lexus',
  LINCOLN = 'Lincoln',
  MAZDA = 'Mazda',
  MERCEDES = 'Mercedes-Benz',
  MINI = 'Mini',
  MITSUBISHI = 'Mitsubishi',
  NISSAN = 'Nissan',
  PORSCHE = 'Porsche',
  RAM = 'Ram',
  SUBARU = 'Subaru',
  TESLA = 'Tesla',
  TOYOTA = 'Toyota',
  VOLKSWAGEN = 'Volkswagen',
  VOLVO = 'Volvo'
}

// FIX: Export FilterState interface to be used for sidebar filters.
export interface FilterState {
  statuses: Status[];
  brands: Brand[];
  assignedToMe: boolean;
  searchTerm: string;
}

// FIX: Add TicketSortKey and SortConfig types for consistent sorting across components.
export type TicketSortKey = 'id' | 'subject' | 'requester' | 'assignee' | 'status' | 'createdAt' | 'dueDate';
export type SortConfig = { key: TicketSortKey; direction: 'asc' | 'desc' };

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: 'admin' | 'tech';
}

export interface TicketUpdate {
  id: string;
  author: string;
  timestamp: string;
  content: string;
}

export interface Vehicle {
  vin: string;
  tag: string;
  year: number;
  make: Brand;
  model: string;
  mileage: number;
}

export interface Part {
  id:string;
  name: string;
  partNumber: string;
  quantity: number;
  cost: number; // Cost per unit
}

export interface ToolRepairDetails {
    program: string;
    ccServices: string;
    tool: string;
    serialNumber: string;
    budgetType: string;
    onHoldTill: string;
    distributor: string;
    supportContact: string;
    billContact: string;
    shipContact: string;
    caseNotes: string;
    dateSent: string;
    sensorSN: string;
    technicianNotes: string;
    partsUsed?: Part[];
}

export enum LoanerToolStatus {
  AVAILABLE = 'Available',
  IN_USE = 'In Use',
  IN_REPAIR = 'In Repair',
}

export interface LoanerTool {
  id: string;
  serialNumber: string;
  type: string;
  status: LoanerToolStatus;
  assignedTicketId?: string;
  purchaseDate: string; // ISO String
  lastServiceDate: string; // ISO String
}

export interface Customer {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  subscriptionStatus: 'Active' | 'Expired' | 'Trial' | 'None';
  liveStatus: 'Online' | 'Offline' | 'Away';
}

export interface Tool {
  serialNumber: string;
  customerId: string;
  model: string;
  purchaseDate: string; // ISO String
  warrantyEndDate: string; // ISO String
}

export interface Ticket {
  id: string;
  subject: string;
  requester: string;
  module: Module;
  status: Status;
  timestamp: string; // User-facing friendly timestamp
  createdAt: string; // ISO 8601 date string for logic
  dueDate?: string; // Optional ISO 8601 date string
  updates: TicketUpdate[];
  vehicle?: Vehicle;
  assignee?: string;
  attachments?: { name: string, url: string }[];
  symptom?: string;
  response?: string;
  toolRepairDetails?: ToolRepairDetails;
  loanerToolId?: string;
  customerId?: string;
  toolSerialNumber?: string;
  privateNotes?: string;
  teamViewerId?: string;
  teamViewerPassword?: string;
  callbackScheduledAt?: string;
  reminderAt?: string; // ISO 8601 date string
}

export interface Sound {
    name: string;
    url: string;
}