import React, { useState, useMemo, useReducer, useEffect } from 'react';
import ModuleTabs from './components/ModuleTabs';
import TicketList from './components/TicketList';
import TicketDetail from './components/TicketDetail';
import Dashboard from './components/Dashboard';
import VehicleDashboard from './components/VehicleDashboard';
import SodReport from './components/SodReport';
import Sidebar from './components/Sidebar';
import NewCaseModal from './components/NewCaseModal';
import NewToolModal from './components/NewToolModal';
import AccountPortal from './components/AccountPortal';
import BottomNavBar from './components/BottomNavBar';
import Settings from './components/Settings';
import Header from './components/Header';
import { MOCK_TICKETS, STATUSES, BRANDS, MOCK_CUSTOMERS, MOCK_TOOLS, Icons, MOCK_USERS, CURRENT_USER, PREDEFINED_SOUNDS, MOCK_LOANER_TOOLS } from './constants';
// FIX: Import SortConfig to use the centralized type for sorting.
import type { Ticket, Module, FilterState, Customer, Tool, User, LoanerTool, SortConfig } from './types';
import { Status, LoanerToolStatus } from './types';

export type View = 'dashboard' | 'cases' | 'vehicle' | 'reports' | 'accounts' | 'settings';

type Action =
  | { type: 'ADD_TICKET'; payload: Ticket }
  | { type: 'UPDATE_TICKET'; payload: Ticket }
  | { type: 'DELETE_TICKET'; payload: string }
  | { type: 'CLEAR_REMINDER'; payload: string };

const ticketsReducer = (state: Ticket[], action: Action): Ticket[] => {
  switch (action.type) {
    case 'ADD_TICKET':
      return [action.payload, ...state];
    case 'UPDATE_TICKET':
      return state.map(ticket =>
        ticket.id === action.payload.id ? action.payload : ticket
      );
    case 'DELETE_TICKET':
      return state.filter(ticket => ticket.id !== action.payload);
    case 'CLEAR_REMINDER':
      return state.map(ticket => 
        ticket.id === action.payload ? { ...ticket, reminderAt: undefined } : ticket
      );
    default:
      return state;
  }
};

const DEFAULT_FILTERS: FilterState = {
  statuses: [],
  brands: [],
  assignedToMe: false,
  searchTerm: '',
};

const App: React.FC = () => {
  const [tickets, dispatch] = useReducer(ticketsReducer, [], () => {
    try {
      const storedTickets = localStorage.getItem('autoland-crm-tickets');
      return storedTickets ? JSON.parse(storedTickets) : MOCK_TICKETS;
    } catch (error) {
      console.error("Error parsing tickets from localStorage", error);
      return MOCK_TICKETS;
    }
  });

  const [customers, setCustomers] = useState<Customer[]>(MOCK_CUSTOMERS);
  const [tools, setTools] = useState<Tool[]>(MOCK_TOOLS);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [isNewToolModalOpen, setIsNewToolModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const [loanerTools, setLoanerTools] = useState<LoanerTool[]>(() => {
    try {
        const stored = localStorage.getItem('autoland-crm-loaner-tools');
        return stored ? JSON.parse(stored) : MOCK_LOANER_TOOLS;
    } catch (error) {
        console.error("Error parsing loaner tools from localStorage", error);
        return MOCK_LOANER_TOOLS;
    }
  });

  useEffect(() => {
    localStorage.setItem('autoland-crm-loaner-tools', JSON.stringify(loanerTools));
  }, [loanerTools]);


  useEffect(() => {
    localStorage.setItem('autoland-crm-tickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    // Simulate loading from an async source
    const timer = setTimeout(() => {
        setIsLoading(false);
    }, 500); // 0.5 second delay
    return () => clearTimeout(timer);
  }, []);
  
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [activeModuleTab, setActiveModuleTab] = useState<Module | 'all'>('all');
  const [isNewCaseModalOpen, setIsNewCaseModalOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);

  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  // FIX: Use the centralized SortConfig type for the sortConfig state. This resolves the type mismatch error.
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'createdAt', direction: 'desc' });

  const playNotificationSound = () => {
    try {
      const soundSettings = localStorage.getItem('autoland-crm-sound-settings');
      let soundToPlay = PREDEFINED_SOUNDS[0]; // Default sound

      if (soundSettings) {
        soundToPlay = JSON.parse(soundSettings);
      }
      
      if (soundToPlay && soundToPlay.url) {
        const audio = new Audio(soundToPlay.url);
        audio.play().catch(error => console.error("Audio playback failed. This may be due to browser autoplay restrictions.", error));
      }
    } catch (error) {
      console.error("Error playing notification sound:", error);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
        const now = new Date();
        const ticketsWithReminders = tickets.filter(t => t.reminderAt);

        for (const ticket of ticketsWithReminders) {
            const reminderDate = new Date(ticket.reminderAt!);
            if (reminderDate <= now) {
                alert(`Reminder for ticket ${ticket.id}: "${ticket.subject}"`);
                playNotificationSound();
                dispatch({ type: 'CLEAR_REMINDER', payload: ticket.id });
            }
        }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [tickets]);

  const sendStatusUpdateEmail = async (ticket: Ticket, customer: Customer, oldStatus: Status) => {
    const emailSubject = `Update on your support ticket: ${ticket.id}`;
    let message: string;

    if (ticket.status === Status.CALL_COMPLETED) {
        message = `We are pleased to inform you that the case has been marked as completed by our team.\n\nHere is a summary of the resolution:\n${ticket.response || 'Please see ticket details for more information.'}`;
    } else {
        message = `The status of your ticket has been updated from "${oldStatus}" to "${ticket.status}".`;
    }

    const emailBody = `
Dear ${customer.name},

This is an update regarding your support ticket "${ticket.subject}".

${message}

If you have any further questions, please don't hesitate to contact us.

Thank you,
Autoland Support
    `;
    
    console.log(`
    --- ZOHO EMAIL SIMULATION ---
    TO: ${customer.email}
    SUBJECT: ${emailSubject}
    BODY: ${emailBody}
    -----------------------------
    `);
    
    // Use a timeout to ensure the UI has time to update before the alert blocks the thread
    setTimeout(() => {
        alert(`A status update email has been sent to ${customer.email} for ticket ${ticket.id}. New status: ${ticket.status}`);
    }, 100);
  };
  
  const createEmailChainForTicket = (ticket: Ticket, customer: Customer) => {
    console.log(`
    --- ZOHO EMAIL CHAIN CREATION ---
    Simulating creation of a new email thread for Ticket ID: ${ticket.id}.
    Participants:
    - Customer: ${customer.name} (${customer.email})
    - Assigned To: ${ticket.assignee || 'Unassigned'}

    This thread will be used for all future email correspondence regarding this ticket.
    ---------------------------------
    `);
  };

  const sendAutomaticResponseEmail = async (ticket: Ticket, customer: Customer) => {
    const emailSubject = `Confirmation: We've Received Your Ticket [${ticket.id}]`;
    const emailBody = `
Dear ${customer.name},

Thank you for contacting Autoland Support. This email confirms that we have received your request and a support ticket has been created for you.

Ticket Details:
- Ticket ID: ${ticket.id}
- Subject: "${ticket.subject}"
- Summary of issue: ${ticket.symptom || 'As described in your request.'}

Our team will review your request and get back to you shortly. You can reply to this email to add any further comments.

Best regards,
The Autoland Support Team
    `;

    console.log(`
    --- ZOHO AUTOMATIC RESPONSE ---
    TO: ${customer.email}
    SUBJECT: ${emailSubject}
    BODY: ${emailBody}
    -------------------------------
    `);
  };

  const emailTicketDataToAssignee = async (ticket: Ticket, assignee: User) => {
    const ticketLink = `${window.location.href.split('?')[0]}?view=cases&ticketId=${ticket.id}`;
    const emailSubject = `[New Ticket] You are assigned to: ${ticket.id} - ${ticket.subject}`;
    const emailBody = `
Hello ${assignee.name},

You have been assigned to a new ticket with the following details:

- Ticket ID: ${ticket.id}
- Subject: ${ticket.subject}
- Requester: ${ticket.requester}
- Module: ${ticket.module}
- Status: ${ticket.status}
- View Ticket: ${ticketLink}

Please review the ticket in the CRM at your earliest convenience.

Thank you,
Autoland Support System
    `;

    console.log(`
    --- ZOHO ASSIGNEE NOTIFICATION ---
    TO: ${assignee.email}
    SUBJECT: ${emailSubject}
    BODY: ${emailBody}
    ----------------------------------
    `);
  };

  const handleSelectTicket = (ticketId: string) => {
    const ticket = tickets.find(t => t.id === ticketId) || null;
    setSelectedTicket(ticket);
    setCurrentView('cases');
  };
  
  const handleNavigate = (view: View, newFilters: Partial<FilterState> = {}, module: Module | 'all' = 'all') => {
    setCurrentView(view);
    setFilters({ ...DEFAULT_FILTERS, ...newFilters });
    setActiveModuleTab(module);

    if (view === 'cases') {
        setSelectedTicket(null);
    }
    if (view !== 'accounts') {
        setSelectedCustomer(null);
    }
  }

  const handleBack = () => {
    if (selectedTicket) {
        setSelectedTicket(null);
    }
    if (selectedCustomer) {
        setSelectedCustomer(null);
    }
  };
  
  const handleClearFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  const isFilterActive = useMemo(() => {
    return filters.statuses.length > 0 ||
           filters.brands.length > 0 ||
           filters.assignedToMe ||
           filters.searchTerm !== '';
  }, [filters]);

  const handleAddTicket = (newTicket: Omit<Ticket, 'id' | 'timestamp' | 'createdAt' | 'updates'>) => {
    const now = new Date();
    const newTicketWithId: Ticket = {
        ...newTicket,
        id: `AT-${Math.floor(Math.random() * 90000) + 10000}-${Math.floor(Math.random() * 9)}`,
        timestamp: `${now.toLocaleDateString()} ${now.toLocaleTimeString()} (just now)`,
        createdAt: now.toISOString(),
        updates: [{
            id: 'update-1',
            author: newTicket.requester,
            timestamp: `${now.toLocaleDateString()} ${now.toLocaleTimeString()}`,
            content: 'Case created.'
        }],
    };
    dispatch({ type: 'ADD_TICKET', payload: newTicketWithId });
    
    const customer = customers.find(c => c.id === newTicket.customerId);
    const assignee = users.find(u => u.name === newTicket.assignee);
    
    if (customer) {
        sendAutomaticResponseEmail(newTicketWithId, customer);
        createEmailChainForTicket(newTicketWithId, customer);
    }
    if (assignee) {
        emailTicketDataToAssignee(newTicketWithId, assignee);
    }
    
    setIsNewCaseModalOpen(false);
    playNotificationSound();
  };
  
  const handleUpdateTicket = (updatedTicket: Ticket) => {
    const originalTicket = tickets.find(t => t.id === updatedTicket.id);
        
    if (originalTicket && originalTicket.status !== updatedTicket.status) {
        const customer = customers.find(c => c.id === updatedTicket.customerId);
        if (customer) {
            sendStatusUpdateEmail(updatedTicket, customer, originalTicket.status);
        } else {
            console.warn(`Could not send email for ticket ${updatedTicket.id}: Customer not found.`);
        }
    }

    if (originalTicket && originalTicket.assignee !== updatedTicket.assignee) {
        const assignee = users.find(u => u.name === updatedTicket.assignee);
        if (assignee) {
            emailTicketDataToAssignee(updatedTicket, assignee);
        }
    }

    if (originalTicket && originalTicket.loanerToolId !== updatedTicket.loanerToolId) {
        setLoanerTools(prevTools => {
            const newTools = [...prevTools];
            // Release old tool
            if (originalTicket.loanerToolId) {
                const oldToolIndex = newTools.findIndex(t => t.id === originalTicket.loanerToolId);
                if (oldToolIndex > -1) {
                    newTools[oldToolIndex] = {
                        ...newTools[oldToolIndex],
                        status: LoanerToolStatus.AVAILABLE,
                        assignedTicketId: undefined,
                    };
                }
            }
            // Assign new tool
            if (updatedTicket.loanerToolId) {
                const newToolIndex = newTools.findIndex(t => t.id === updatedTicket.loanerToolId);
                if (newToolIndex > -1) {
                    newTools[newToolIndex] = {
                        ...newTools[newToolIndex],
                        status: LoanerToolStatus.IN_USE,
                        assignedTicketId: updatedTicket.id,
                    };
                }
            }
            return newTools;
        });
    }

    dispatch({ type: 'UPDATE_TICKET', payload: updatedTicket });
  };
  
  const handleDeleteTicket = (ticketId: string) => {
    dispatch({ type: 'DELETE_TICKET', payload: ticketId });
    setSelectedTicket(null);
  };
  
  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(prevCustomers =>
      prevCustomers.map(c => (c.id === updatedCustomer.id ? updatedCustomer : c))
    );
    if (selectedCustomer?.id === updatedCustomer.id) {
      setSelectedCustomer(updatedCustomer);
    }
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(prevUsers =>
      prevUsers.map(u => (u.id === updatedUser.id ? updatedUser : u))
    );
  };

  const handleAddTool = (newTool: Omit<Tool, 'customerId'>) => {
    if (!selectedCustomer) return;
    const toolToAdd: Tool = {
      ...newTool,
      customerId: selectedCustomer.id,
    };
    setTools(prevTools => [toolToAdd, ...prevTools]);
    setIsNewToolModalOpen(false);
  };

  const filteredTickets = useMemo(() => {
    let filtered = tickets.filter(ticket => {
      // Module tab filter
      if (activeModuleTab !== 'all' && ticket.module !== activeModuleTab) {
        return false;
      }
      // Statuses filter
      if (filters.statuses.length > 0 && !filters.statuses.includes(ticket.status)) {
        return false;
      }
      // Brands filter
      if (filters.brands.length > 0 && !(ticket.vehicle && filters.brands.includes(ticket.vehicle.make))) {
        return false;
      }
      // Assigned to me filter
      if (filters.assignedToMe && ticket.assignee !== CURRENT_USER.name) {
        return false;
      }
      // Search term filter
      if (filters.searchTerm) {
          const term = filters.searchTerm.toLowerCase();
          const inSubject = ticket.subject.toLowerCase().includes(term);
          const inRequester = ticket.requester.toLowerCase().includes(term);
          const inId = ticket.id.toLowerCase().includes(term);
          const inSymptom = ticket.symptom?.toLowerCase().includes(term);
          const inResponse = ticket.response?.toLowerCase().includes(term);
          if (!inSubject && !inRequester && !inId && !inSymptom && !inResponse) {
              return false;
          }
      }

      return true;
    });

    if (sortConfig.key) {
        filtered.sort((a, b) => {
            const aVal = a[sortConfig.key as keyof Ticket];
            const bVal = b[sortConfig.key as keyof Ticket];

            if (aVal === undefined || aVal === null) return 1;
            if (bVal === undefined || bVal === null) return -1;
            
            let comparison = 0;
            if (aVal > bVal) {
                comparison = 1;
            } else if (aVal < bVal) {
                comparison = -1;
            }
            return sortConfig.direction === 'desc' ? -comparison : comparison;
        });
    }

    return filtered;

  }, [tickets, activeModuleTab, filters, sortConfig]);

  const renderCasesView = () => {
    if (selectedTicket) {
      return (
        <div className="flex-1 overflow-y-auto">
          <TicketDetail 
            ticket={selectedTicket} 
            users={users}
            customers={customers}
            loanerTools={loanerTools}
            onUpdateTicket={handleUpdateTicket}
            onDeleteTicket={handleDeleteTicket}
            currentUser={CURRENT_USER}
          />
        </div>
      );
    }
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <ModuleTabs activeTab={activeModuleTab} onTabSelect={setActiveModuleTab} />
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto bg-gray-900">
            <TicketList 
                tickets={filteredTickets} 
                onSelectTicket={handleSelectTicket}
                filters={filters}
                onFilterChange={setFilters}
                onFilterToggle={() => setIsFilterModalOpen(true)}
                isFilterActive={isFilterActive}
                sortConfig={sortConfig}
                onSortChange={setSortConfig}
                users={users}
                onUpdateTicket={handleUpdateTicket}
            />
        </main>
      </div>
    );
  }
  
  const renderFilterModal = () => (
    <div 
        className="fixed inset-0 bg-black bg-opacity-75 flex flex-col justify-end sm:items-center sm:justify-center z-50 print:hidden"
        onClick={() => setIsFilterModalOpen(false)}
        role="dialog"
        aria-modal="true"
        aria-labelledby="filter-heading"
    >
        <div 
            className="bg-gray-800 border-t sm:border border-gray-700 rounded-t-lg sm:rounded-lg shadow-xl w-full sm:w-auto animate-slide-up sm:animate-none"
            onClick={(e) => e.stopPropagation()}
        >
             <div className="flex justify-between items-center p-4 border-b border-gray-700">
                <h2 id="filter-heading" className="text-lg font-bold">Filter Cases</h2>
                <button onClick={() => setIsFilterModalOpen(false)} className="text-gray-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
             </div>
             <Sidebar
                statuses={STATUSES}
                brands={BRANDS}
                filters={filters}
                onFilterChange={setFilters}
                onClearFilters={handleClearFilters}
            />
        </div>
    </div>
  );

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard 
                    tickets={tickets} 
                    users={users}
                    loanerTools={loanerTools}
                    onSelectTicket={handleSelectTicket} 
                    onNavigate={handleNavigate}
                    onNewCase={() => setIsNewCaseModalOpen(true)}
                />;
      case 'accounts':
        return (
            <AccountPortal 
                customers={customers}
                tickets={tickets}
                tools={tools}
                selectedCustomer={selectedCustomer}
                onSelectCustomer={setSelectedCustomer}
                onNewCaseForCustomer={() => setIsNewCaseModalOpen(true)}
                onUpdateCustomer={handleUpdateCustomer}
                onAddNewTool={() => setIsNewToolModalOpen(true)}
            />
        );
      case 'vehicle':
        return <VehicleDashboard tickets={tickets} />;
      case 'reports':
        return <SodReport tickets={tickets} />;
      case 'cases':
        return renderCasesView();
      case 'settings':
        return <Settings users={users} onUpdateUser={handleUpdateUser} />;
      default:
        return null;
    }
  };
  
  const customerTools = useMemo(() => {
    if (!selectedCustomer) return [];
    return tools.filter(tool => tool.customerId === selectedCustomer.id);
  }, [selectedCustomer, tools]);

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-gray-900">
        <div role="status">
            <svg aria-hidden="true" className="w-10 h-10 text-gray-600 animate-spin fill-red-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
                <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0492C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5424 39.6781 93.9676 39.0409Z" fill="currentFill"/>
            </svg>
            <span className="sr-only">Loading...</span>
        </div>
        <p className="text-white text-lg mt-4">Loading CRM...</p>
      </div>
    );
  }

  const getHeaderTitle = (): string => {
    if (selectedTicket) return `Ticket ${selectedTicket.id}`;
    if (selectedCustomer) return selectedCustomer.name;
    switch (currentView) {
        case 'dashboard': return 'Dashboard';
        case 'cases': return 'Cases';
        case 'accounts': return 'Customer Accounts';
        case 'vehicle': return 'Vehicle Dashboard';
        case 'reports': return 'SOD Report';
        case 'settings': return 'Settings';
        default: return 'Autoland CRM';
    }
  };

  const showBack = selectedTicket !== null || selectedCustomer !== null;

  return (
    <div className="h-screen w-screen flex flex-col bg-gray-900 overflow-hidden">
      <Header 
        title={getHeaderTitle()}
        showBack={showBack}
        onBack={handleBack}
      />
      {isNewCaseModalOpen && (
          <NewCaseModal 
            onClose={() => setIsNewCaseModalOpen(false)}
            onAddTicket={handleAddTicket}
            customer={selectedCustomer || undefined}
            customerTools={customerTools}
            users={users}
          />
      )}
      {isNewToolModalOpen && selectedCustomer && (
        <NewToolModal
          onClose={() => setIsNewToolModalOpen(false)}
          onAddTool={handleAddTool}
          customerId={selectedCustomer.id}
        />
      )}
      {isFilterModalOpen && renderFilterModal()}
      
      <main className="flex-1 overflow-y-auto pt-16 pb-20">
        {renderContent()}
      </main>
      
      { currentView !== 'cases' || !selectedTicket ? (
        <button
            onClick={() => setIsNewCaseModalOpen(true)}
            className="fixed bottom-24 right-4 sm:right-6 bg-red-600 hover:bg-red-700 text-white rounded-full p-4 shadow-lg z-40 transition-transform hover:scale-110 print:hidden"
            aria-label="Create New Case"
        >
          <div className="w-6 h-6">
            {Icons.plus}
          </div>
        </button>
      ) : null }

      <BottomNavBar currentView={currentView} onNavigate={handleNavigate} currentUser={CURRENT_USER} />
    </div>
  );
};

export default App;