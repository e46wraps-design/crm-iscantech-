
import React, { useMemo, useState, useEffect } from 'react';
import type { Ticket, Brand } from '../types';
import { Status } from '../types';
import { BRANDS, Icons } from '../constants';
import TicketDataTable from './TicketDataTable';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-5 flex items-center shadow-lg">
        <div className={`mr-4 p-3 rounded-full ${color}`}>
            {icon}
        </div>
        <div>
            <div className="text-3xl font-bold text-white">{value}</div>
            <div className="text-sm text-gray-400 uppercase tracking-wider">{title}</div>
        </div>
    </div>
);

const WorldClock: React.FC<{ timeZone: string; label: string }> = ({ timeZone, label }) => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    const timeString = time.toLocaleTimeString('en-US', {
        timeZone,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
    });

    return (
        <div className="flex justify-between items-center text-gray-300">
            <span className="font-semibold">{label}</span>
            <span className="font-mono bg-gray-700 px-2 py-1 rounded-md text-sm">{timeString}</span>
        </div>
    );
};

interface VehicleDashboardProps {
    tickets: Ticket[];
}

const VehicleDashboard: React.FC<VehicleDashboardProps> = ({ tickets }) => {

    const stats = useMemo(() => {
        const openTickets = tickets.filter(t => t.status !== Status.CALL_COMPLETED);
        const closedTickets = tickets.filter(t => t.status === Status.CALL_COMPLETED);

        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        
        const totalToday = tickets.filter(t => {
            const createdAt = new Date(t.createdAt).getTime();
            return createdAt >= todayStart;
        }).length;

        const byBrandOpen = openTickets.reduce((acc, ticket) => {
            if (ticket.vehicle) {
                acc[ticket.vehicle.make] = (acc[ticket.vehicle.make] || 0) + 1;
            }
            return acc;
        }, {} as Record<Brand, number>);

        const byBrandTotal = tickets.reduce((acc, ticket) => {
            if (ticket.vehicle) {
                acc[ticket.vehicle.make] = (acc[ticket.vehicle.make] || 0) + 1;
            }
            return acc;
        }, {} as Record<Brand, number>);

        return {
            open: openTickets.length,
            closed: closedTickets.length,
            totalToday,
            byBrandOpen,
            byBrandTotal,
        };
    }, [tickets]);

    const totalCases = stats.open + stats.closed;
    const getBarHeight = (count: number) => {
        if (totalCases === 0) return '0%';
        // Cap height at 100% of the container
        const percentage = (count / totalCases) * 100;
        return `${Math.min(percentage, 100)}%`;
    };

    return (
        <div className="space-y-6 p-4 sm:p-6">
            {/* Top row: Graph and Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Graph */}
                <div className="lg:col-span-2 bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                    <h2 className="text-xl font-bold text-white mb-4">Case Status Overview</h2>
                    <div className="flex items-end justify-around space-x-2 sm:space-x-8 h-64 pt-8">
                        {/* Open Bar */}
                        <div className="flex flex-col items-center flex-1 h-full">
                            <span className="text-3xl font-bold text-white">{stats.open}</span>
                            <div className="w-1/2 mt-2 flex-1 flex items-end">
                               <div className="w-full bg-blue-500 rounded-t-lg" style={{ height: getBarHeight(stats.open) }}></div>
                            </div>
                            <div className="mt-2 text-sm font-semibold text-gray-400">Open</div>
                        </div>
                        {/* Closed Bar */}
                        <div className="flex flex-col items-center flex-1 h-full">
                            <span className="text-3xl font-bold text-white">{stats.closed}</span>
                            <div className="w-1/2 mt-2 flex-1 flex items-end">
                                <div className="w-full bg-green-500 rounded-t-lg" style={{ height: getBarHeight(stats.closed) }}></div>
                            </div>
                            <div className="mt-2 text-sm font-semibold text-gray-400">Closed</div>
                        </div>
                         {/* Total Bar */}
                        <div className="flex flex-col items-center flex-1 h-full">
                            <span className="text-3xl font-bold text-white">{totalCases}</span>
                            <div className="w-1/2 mt-2 flex-1 flex items-end">
                                <div className="w-full bg-purple-500 rounded-t-lg" style={{ height: getBarHeight(totalCases) }}></div>
                            </div>
                            <div className="mt-2 text-sm font-semibold text-gray-400">Total</div>
                        </div>
                    </div>
                </div>

                {/* Stats & Clocks */}
                <div className="space-y-6">
                    <StatCard title="Total Cases Today" value={stats.totalToday} icon={Icons.plus} color="bg-green-500/30 text-green-300" />
                    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                        <h2 className="text-xl font-bold text-white mb-4">World Clocks</h2>
                        <div className="space-y-3">
                            <WorldClock timeZone="America/Los_Angeles" label="PST" />
                            <WorldClock timeZone="America/New_York" label="EST" />
                            <WorldClock timeZone="America/Chicago" label="CST" />
                            <WorldClock timeZone="Europe/London" label="GMT" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Brand Stats */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                 <h2 className="text-xl font-bold text-white mb-4">Open Cases by Brand</h2>
                 <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                     {BRANDS.map(brand => (
                        <div key={brand.id} className="bg-gray-900/70 border border-gray-700 p-3 rounded-lg text-center shadow-md transition hover:bg-gray-700/50 hover:border-gray-600">
                            <div className="font-semibold text-gray-300 text-sm truncate">{brand.label}</div>
                            <div className="text-3xl font-black text-red-400 mt-1">{stats.byBrandOpen[brand.id] || 0}</div>
                            <div className="text-xs text-gray-500 mt-1">
                                Total Cases: <span className="font-bold text-gray-400">{stats.byBrandTotal[brand.id] || 0}</span>
                            </div>
                        </div>
                    ))}
                 </div>
            </div>
            
            {/* All Tickets Table */}
            <div className="mt-6">
                <TicketDataTable tickets={tickets} />
            </div>
        </div>
    );
};

export default VehicleDashboard;
