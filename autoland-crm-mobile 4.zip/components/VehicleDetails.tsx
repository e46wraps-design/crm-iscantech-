

import React from 'react';
import type { Vehicle } from '../types';
import { Icons } from '../constants';

interface VehicleDetailsProps {
  vehicle: Vehicle;
}

const DetailRow: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="grid grid-cols-2 gap-2 text-sm">
    <span className="text-gray-400 font-semibold">{label}</span>
    <span className="text-gray-200">{value}</span>
  </div>
);

const VehicleDetails: React.FC<VehicleDetailsProps> = ({ vehicle }) => {
  return (
    <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg shadow-md">
        <div className="flex items-center p-3 border-b border-gray-700/50">
            <div className="w-5 h-5 mr-2 text-gray-400">{Icons.vehicle}</div>
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider">Vehicle Details</h3>
        </div>
        <div className="p-4 space-y-2">
            <DetailRow label="VIN" value={vehicle.vin} />
            <DetailRow label="Tag" value={vehicle.tag} />
            <DetailRow label="Year" value={vehicle.year} />
            <DetailRow label="Make" value={vehicle.make} />
            <DetailRow label="Model" value={vehicle.model} />
            <DetailRow label="Mileage" value={vehicle.mileage.toLocaleString()} />
        </div>
    </div>
  );
};

export default VehicleDetails;