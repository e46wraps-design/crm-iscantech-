import React, { useMemo } from 'react';
import { Icons } from '../constants';
import type { View } from '../App';
import type { User } from '../types';


interface BottomNavBarProps {
    currentView: View;
    onNavigate: (view: View) => void;
    currentUser: User;
}

const navItems: { id: View, label: string, icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Icons.dashboard },
    { id: 'accounts', label: 'Accounts', icon: Icons.accounts },
    { id: 'vehicle', label: 'Vehicle', icon: Icons.vehicle },
    { id: 'cases', label: 'Cases', icon: Icons.cases },
    { id: 'reports', label: 'Reports', icon: Icons.reports },
    { id: 'settings', label: 'Settings', icon: Icons.settings },
];

const NavItem: React.FC<{
    item: { id: View, label: string, icon: React.ReactNode };
    isActive: boolean;
    onClick: () => void;
}> = ({ item, isActive, onClick }) => {
    
    const activeClasses = "text-red-400";
    const inactiveClasses = "text-gray-400 hover:text-white";

    return (
        <button
            onClick={onClick}
            className={`flex flex-col items-center justify-center flex-1 transition-colors duration-200 ${isActive ? activeClasses : inactiveClasses}`}
            aria-current={isActive ? 'page' : undefined}
        >
            {item.icon}
            <span className="text-xs font-medium mt-1">{item.label}</span>
        </button>
    )
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentView, onNavigate, currentUser }) => {
    const visibleNavItems = useMemo(() => {
        if (currentUser.role === 'admin') {
            return navItems;
        }
        return navItems.filter(item => item.id !== 'settings');
    }, [currentUser.role]);

    return (
        <nav className="fixed bottom-0 left-0 right-0 h-20 bg-gray-800 border-t border-gray-700 flex justify-around items-center z-40 print:hidden">
            {visibleNavItems.map(item => (
                <NavItem 
                    key={item.id}
                    item={item}
                    isActive={currentView === item.id}
                    onClick={() => onNavigate(item.id)}
                />
            ))}
        </nav>
    );
};

export default BottomNavBar;