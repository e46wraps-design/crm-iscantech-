
import React, { useState, useEffect, useMemo } from 'react';
import type { Customer, Ticket, Tool } from '../types';
import { Status } from '../types';
import TicketDataTable from './TicketDataTable';
import { Icons } from '../constants';

interface AccountDetailProps {
  customer: Customer;
  tickets: Ticket[];
  tools: Tool[];
  onNewCase: () => void;
  onUpdateCustomer: (customer: Customer) => void;
  onAddNewTool: () => void;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode; className?: string, rightHeaderContent?: React.ReactNode }> = ({ title, children, className, rightHeaderContent }) => (
    <div className={`bg-gray-800 border border-gray-700 rounded-lg shadow-lg p-6 ${className}`}>
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-white">{title}</h2>
            {rightHeaderContent}
        </div>
        {children}
    </div>
);

const EditableDetailItem: React.FC<{ label: string; name: keyof Customer; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ label, name, value, onChange }) => (
    <div>
        <label htmlFor={name} className="text-sm text-gray-400">{label}</label>
        <input
            id={name}
            name={name}
            type="text"
            value={value}
            onChange={onChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 mt-1 text-md font-semibold text-gray-200 focus:ring-red-500 focus:border-red-500"
        />
    </div>
);

const AccountDetail: React.FC<AccountDetailProps> = ({ customer, tickets, tools, onNewCase, onUpdateCustomer, onAddNewTool }) => {
  const [editableCustomer, setEditableCustomer] = useState<Customer>(customer);
  const [isSaved, setIsSaved] = useState(false);
  const [ticketFilter, setTicketFilter] = useState<'all' | 'open' | 'closed'>('all');

  useEffect(() => {
    setEditableCustomer(customer);
  }, [customer]);

  const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditableCustomer(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = () => {
    onUpdateCustomer(editableCustomer);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  }

  const filteredTickets = useMemo(() => {
    if (ticketFilter === 'open') {
      return tickets.filter(t => t.status !== Status.CALL_COMPLETED);
    }
    if (ticketFilter === 'closed') {
      return tickets.filter(t => t.status === Status.CALL_COMPLETED);
    }
    return tickets;
  }, [tickets, ticketFilter]);

  const getFilterButtonClasses = (filter: 'all' | 'open' | 'closed') => {
    const base = 'px-4 py-2 rounded-md text-sm font-medium transition';
    if (filter === ticketFilter) {
      return `${base} bg-red-600 text-white shadow-md`;
    }
    return `${base} bg-gray-700 hover:bg-gray-600 text-gray-300`;
  };

  return (
    <div className="space-y-6">
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          {/* Customer Info */}
          <InfoCard title="Contact Information">
            <div className="space-y-4">
                <EditableDetailItem label="Email" name="email" value={editableCustomer.email} onChange={handleInfoChange} />
                <EditableDetailItem label="Phone" name="phone" value={editableCustomer.phone} onChange={handleInfoChange} />
                <EditableDetailItem label="Address" name="address" value={editableCustomer.address} onChange={handleInfoChange} />
            </div>
            <div className="flex justify-end mt-4">
                <button onClick={handleSaveChanges} className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded transition text-sm disabled:bg-green-600 disabled:cursor-not-allowed" disabled={isSaved}>
                    {isSaved ? 'Saved!' : 'Save Changes'}
                </button>
            </div>
          </InfoCard>

          {/* Registered Tools */}
          <InfoCard 
            title="Registered Tools"
            rightHeaderContent={
                <button onClick={onAddNewTool} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-1 px-3 rounded-md transition text-xs flex items-center">
                    <div className="w-4 h-4">{Icons.plus}</div>
                    <span className="ml-1">Add Tool</span>
                </button>
            }
            >
            {tools.length > 0 ? (
                <div className="space-y-3">
                    {tools.map(tool => {
                        const isWarrantyActive = new Date(tool.warrantyEndDate) >= new Date();
                        return (
                            <div key={tool.serialNumber} className="bg-gray-900/50 p-3 rounded-md border border-gray-700">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="font-bold text-red-400 text-sm">{tool.model}</p>
                                        <p className="text-xs text-gray-400">S/N: {tool.serialNumber}</p>
                                    </div>
                                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${isWarrantyActive ? 'bg-green-600/80 text-green-100' : 'bg-red-600/80 text-red-100'}`}>
                                        {isWarrantyActive ? 'Active' : 'Expired'}
                                    </span>
                                </div>
                                <div className="text-xs text-gray-500 mt-2 pt-2 border-t border-gray-700/50 grid grid-cols-2 gap-x-2">
                                    <p>Purchased: <span className="text-gray-400">{new Date(tool.purchaseDate).toLocaleDateString()}</span></p>
                                    <p>Warranty End: <span className="text-gray-400">{new Date(tool.warrantyEndDate).toLocaleDateString()}</span></p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <p className="text-gray-500">No tools registered for this customer.</p>
            )}
          </InfoCard>
        </div>

        <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4 bg-gray-800 border border-gray-700 rounded-lg p-2 max-w-min">
                <button onClick={() => setTicketFilter('all')} className={getFilterButtonClasses('all')}>All</button>
                <button onClick={() => setTicketFilter('open')} className={getFilterButtonClasses('open')}>Open</button>
                <button onClick={() => setTicketFilter('closed')} className={getFilterButtonClasses('closed')}>Closed</button>
            </div>
           <TicketDataTable tickets={filteredTickets} />
        </div>
      </div>
    </div>
  );
};

export default AccountDetail;
