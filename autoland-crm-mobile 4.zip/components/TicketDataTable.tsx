import React, { useState, useMemo } from 'react';
import type { Ticket, Status } from '../types';
import { Icons, STATUSES } from '../constants';

type SortableKeys = keyof Pick<Ticket, 'id' | 'subject' | 'requester' | 'status' | 'assignee'> | 'timestamp';

interface TicketDataTableProps {
  tickets: Ticket[];
}

const SortableHeader: React.FC<{
  label: string;
  sortKey: SortableKeys;
  sortConfig: { key: SortableKeys; direction: 'ascending' | 'descending' } | null;
  requestSort: (key: SortableKeys) => void;
}> = ({ label, sortKey, sortConfig, requestSort }) => {
  const isSorted = sortConfig?.key === sortKey;
  const directionIcon = isSorted ? (sortConfig.direction === 'ascending' ? '▲' : '▼') : '';

  return (
    <th
      scope="col"
      className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-700/80 transition-colors"
      onClick={() => requestSort(sortKey)}
    >
      <div className="flex items-center">
        {label}
        <span className="ml-2 text-red-400">{directionIcon}</span>
      </div>
    </th>
  );
};

const TicketDataTable: React.FC<TicketDataTableProps> = ({ tickets }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<Status | 'all'>('all');
  const [assigneeFilter, setAssigneeFilter] = useState<string | 'all'>('all');
  const [sortConfig, setSortConfig] = useState<{
    key: SortableKeys;
    direction: 'ascending' | 'descending';
  } | null>({ key: 'timestamp', direction: 'descending' });

  const assignees = useMemo(() => {
    const allAssignees = tickets.map(t => t.assignee).filter(Boolean) as string[];
    return ['All', ...Array.from(new Set(allAssignees))];
  }, [tickets]);

  const filteredTickets = useMemo(() => {
    return tickets.filter(ticket => {
      const lowercasedTerm = searchTerm.toLowerCase();
      const matchesSearch =
        ticket.id.toLowerCase().includes(lowercasedTerm) ||
        ticket.subject.toLowerCase().includes(lowercasedTerm) ||
        ticket.requester.toLowerCase().includes(lowercasedTerm) ||
        ticket.symptom?.toLowerCase().includes(lowercasedTerm) ||
        ticket.response?.toLowerCase().includes(lowercasedTerm);

      const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
      const matchesAssignee = assigneeFilter === 'All' || ticket.assignee === assigneeFilter;

      return matchesSearch && matchesStatus && matchesAssignee;
    });
  }, [tickets, searchTerm, statusFilter, assigneeFilter]);

  const sortedTickets = useMemo(() => {
    let sortableItems = [...filteredTickets];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = sortConfig.key === 'timestamp' ? new Date(a.createdAt) : a[sortConfig.key];
        const bValue = sortConfig.key === 'timestamp' ? new Date(b.createdAt) : b[sortConfig.key];
        
        if (aValue === undefined || aValue === null) return 1;
        if (bValue === undefined || bValue === null) return -1;

        if (aValue < bValue) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [filteredTickets, sortConfig]);

  const requestSort = (key: SortableKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const statusColors: { [key in Status]: string } = {
    'Call completed': 'bg-green-600/80 text-green-100',
    'Callback no voicemail': 'bg-yellow-600/80 text-yellow-100',
    'Awaiting Reply': 'bg-blue-600/80 text-blue-100',
    'New': 'bg-purple-600/80 text-purple-100',
    'In Progress': 'bg-orange-600/80 text-orange-100',
  };

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
        <h2 className="text-xl font-bold text-white">All Tickets</h2>
        <div className="flex items-center space-x-2">
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as Status | 'all')}
            className="bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-red-500 text-sm"
            aria-label="Filter by status"
          >
            <option value="all">All Statuses</option>
            {STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>

           <select
            value={assigneeFilter}
            onChange={e => setAssigneeFilter(e.target.value)}
            className="bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-red-500 text-sm"
            aria-label="Filter by assignee"
          >
            {assignees.map(a => <option key={a} value={a}>{a}</option>)}
          </select>

          <div className="relative">
            <input
              type="text"
              placeholder="Filter tickets..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-red-500 w-64"
              aria-label="Filter tickets by ID, Subject, Requester, symptom, or response"
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
              {Icons.search}
            </div>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-700/50">
            <tr>
              <SortableHeader label="Ticket ID" sortKey="id" sortConfig={sortConfig} requestSort={requestSort} />
              <SortableHeader label="Subject" sortKey="subject" sortConfig={sortConfig} requestSort={requestSort} />
              <SortableHeader label="Requester" sortKey="requester" sortConfig={sortConfig} requestSort={requestSort} />
              <SortableHeader label="Assignee" sortKey="assignee" sortConfig={sortConfig} requestSort={requestSort} />
              <SortableHeader label="Status" sortKey="status" sortConfig={sortConfig} requestSort={requestSort} />
              <SortableHeader label="Last Updated" sortKey="timestamp" sortConfig={sortConfig} requestSort={requestSort} />
            </tr>
          </thead>
          <tbody className="bg-gray-800 divide-y divide-gray-700">
            {sortedTickets.map(ticket => (
              <tr key={ticket.id} className="hover:bg-gray-700/50 transition-colors">
                <td className="p-3 text-sm font-medium text-red-400 whitespace-nowrap">{ticket.id}</td>
                <td className="p-3 text-sm text-gray-300 max-w-xs truncate">{ticket.subject}</td>
                <td className="p-3 text-sm text-gray-300 whitespace-nowrap">{ticket.requester}</td>
                <td className="p-3 text-sm text-gray-300 whitespace-nowrap">{ticket.assignee}</td>
                <td className="p-3 text-sm text-gray-300 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[ticket.status] || 'bg-gray-600 text-gray-100'}`}>
                    {ticket.status}
                  </span>
                </td>
                <td className="p-3 text-sm text-gray-400 whitespace-nowrap">{ticket.timestamp}</td>
              </tr>
            ))}
            {sortedTickets.length === 0 && (
                <tr>
                    <td colSpan={6} className="text-center py-10 text-gray-500">
                        No tickets match your search.
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TicketDataTable;