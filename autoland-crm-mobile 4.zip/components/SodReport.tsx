
import React, { useState, useMemo } from 'react';
import type { Ticket } from '../types';
import { Module, Status } from '../types';

interface SodReportProps {
  tickets: Ticket[];
}

const SodReport: React.FC<SodReportProps> = ({ tickets }) => {
  const getInitialDateRange = () => {
    const now = new Date();
    const startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    const endDate = new Date();
    return {
      start: startDate.toISOString().split('T')[0], // format YYYY-MM-DD
      end: endDate.toISOString().split('T')[0],
    };
  };

  const [dateRange, setDateRange] = useState(getInitialDateRange());

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDateRange(prev => ({ ...prev, [name]: value }));
  };

  const sodTicketsByAssignee = useMemo(() => {
    if (!dateRange.start || !dateRange.end) {
      return {};
    }

    // By setting the time to the beginning of the start day and the end of the end day,
    // we ensure the date range filter is inclusive of the selected dates.
    const startDate = new Date(`${dateRange.start}T00:00:00`);
    const endDate = new Date(`${dateRange.end}T23:59:59`);

    const filtered = tickets.filter(ticket => {
      if (ticket.module !== Module.SOD) return false;
      const ticketDate = new Date(ticket.createdAt);
      return (
        ticketDate >= startDate &&
        ticketDate <= endDate &&
        ticket.assignee
      );
    });

    return filtered.reduce((acc, ticket) => {
      const assignee = ticket.assignee!;
      if (!acc[assignee]) {
        acc[assignee] = {
          tickets: [],
          statusCounts: {} as Record<Status, number>,
        };
      }
      acc[assignee].tickets.push(ticket);
      acc[assignee].statusCounts[ticket.status] = (acc[assignee].statusCounts[ticket.status] || 0) + 1;
      return acc;
    }, {} as Record<string, { tickets: Ticket[]; statusCounts: Record<Status, number> }>);
  }, [tickets, dateRange]);

  const handlePrint = () => {
    window.print();
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    // Use T00:00:00 to ensure date is parsed in local timezone, not UTC.
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US');
  }

  return (
    <div className="space-y-6 p-4 sm:p-6" id="sod-report-container">
      <div className="flex flex-col sm:flex-row justify-end sm:items-center print:hidden gap-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <div className="flex items-center space-x-2">
              <label htmlFor="start" className="text-sm text-gray-400">Start</label>
              <input type="date" name="start" value={dateRange.start} onChange={handleDateChange} className="bg-gray-700 border border-gray-600 rounded-md p-2 text-sm w-full focus:ring-red-500 focus:border-red-500" />
            </div>
            <div className="flex items-center space-x-2">
              <label htmlFor="end" className="text-sm text-gray-400">End</label>
              <input type="date" name="end" value={dateRange.end} onChange={handleDateChange} className="bg-gray-700 border border-gray-600 rounded-md p-2 text-sm w-full focus:ring-red-500 focus:border-red-500" />
            </div>
            <button onClick={handlePrint} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition">Print Report</button>
        </div>
      </div>
      
      <div className="space-y-8">
        {Object.keys(sodTicketsByAssignee).length > 0 ? (
          Object.entries(sodTicketsByAssignee).map(([assignee, data]) => (
            <div key={assignee} className="bg-gray-800 border border-gray-700 rounded-lg shadow-lg p-6 break-inside-avoid">
              <h2 className="text-2xl font-bold text-red-400 mb-4">{assignee}</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gray-900/50 p-3 rounded-md">
                    <div className="text-sm text-gray-400">Total Cases</div>
                    <div className="text-2xl font-bold text-white">{data.tickets.length}</div>
                </div>
                {Object.entries(data.statusCounts).map(([status, count]) => (
                    <div key={status} className="bg-gray-900/50 p-3 rounded-md">
                        <div className="text-sm text-gray-400">{status}</div>
                        <div className="text-2xl font-bold text-white">{count}</div>
                    </div>
                ))}
              </div>

              <h3 className="text-lg font-semibold text-white mb-2">Case Details</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-700/50">
                        <tr>
                            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Ticket ID</th>
                            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Subject</th>
                            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Created Date</th>
                        </tr>
                    </thead>
                    <tbody className="bg-gray-800 divide-y divide-gray-700">
                        {data.tickets.map(ticket => (
                            <tr key={ticket.id}>
                                <td className="p-3 text-sm font-medium text-gray-300">{ticket.id}</td>
                                <td className="p-3 text-sm text-gray-300">{ticket.subject}</td>
                                <td className="p-3 text-sm text-gray-300">{ticket.status}</td>
                                <td className="p-3 text-sm text-gray-400 whitespace-nowrap">{new Date(ticket.createdAt).toLocaleDateString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
              </div>
            </div>
          ))
        ) : (
            <div className="text-center py-10 text-gray-500 bg-gray-800 rounded-lg">
                <p>No SOD tickets found for the selected date range ({formatDate(dateRange.start)} - {formatDate(dateRange.end)}).</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default SodReport;
