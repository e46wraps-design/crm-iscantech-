
import React, { useMemo } from 'react';
import type { Part } from '../types';

interface PartsTrackerProps {
  parts: Part[];
  onPartChange: (index: number, field: keyof Part, value: string | number) => void;
  onRemovePart: (index: number) => void;
}

const PartsTracker: React.FC<PartsTrackerProps> = ({ parts, onPartChange, onRemovePart }) => {
  const totalCost = useMemo(() => {
    return parts.reduce((acc, part) => acc + (Number(part.quantity) * Number(part.cost)), 0);
  }, [parts]);

  return (
    <div>
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-700/50">
                    <tr>
                        <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Part Name</th>
                        <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Part Number</th>
                        <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Qty</th>
                        <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Unit Cost</th>
                        <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Line Total</th>
                        <th className="p-3"></th>
                    </tr>
                </thead>
                <tbody className="bg-gray-800 divide-y divide-gray-700">
                    {parts.map((part, index) => (
                        <tr key={part.id}>
                            <td><input type="text" value={part.name} onChange={e => onPartChange(index, 'name', e.target.value)} className="w-full bg-transparent p-2 focus:bg-gray-900 rounded focus:outline-none focus:ring-1 focus:ring-red-500" /></td>
                            <td><input type="text" value={part.partNumber} onChange={e => onPartChange(index, 'partNumber', e.target.value)} className="w-full bg-transparent p-2 focus:bg-gray-900 rounded focus:outline-none focus:ring-1 focus:ring-red-500" /></td>
                            <td><input type="number" value={part.quantity} onChange={e => onPartChange(index, 'quantity', parseInt(e.target.value, 10) || 0)} className="w-20 bg-transparent p-2 focus:bg-gray-900 rounded focus:outline-none focus:ring-1 focus:ring-red-500" /></td>
                            <td><input type="number" value={part.cost} onChange={e => onPartChange(index, 'cost', parseFloat(e.target.value) || 0)} className="w-24 bg-transparent p-2 focus:bg-gray-900 rounded focus:outline-none focus:ring-1 focus:ring-red-500" /></td>
                            <td className="p-3 text-sm text-gray-300">${(part.quantity * part.cost).toFixed(2)}</td>
                            <td className="p-3 text-center">
                                <button onClick={() => onRemovePart(index)} className="text-gray-500 hover:text-red-500">&times;</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        <div className="flex justify-end items-center mt-4">
            <div className="text-right">
                <span className="text-gray-400 font-semibold">Total Parts Cost:</span>
                <span className="text-xl font-bold text-white ml-2">${totalCost.toFixed(2)}</span>
            </div>
        </div>
    </div>
  );
};

export default PartsTracker;
