import React, { useState, useEffect } from 'react';
import type { Ticket, Customer, Tool, User } from '../types';
import { Module, Status } from '../types';
import { MODULES, STATUSES, CURRENT_USER } from '../constants';

interface NewCaseModalProps {
    onClose: () => void;
    onAddTicket: (newTicket: Omit<Ticket, 'id' | 'timestamp' | 'createdAt' | 'updates'>) => void;
    customer?: Customer;
    customerTools?: Tool[];
    users: User[];
}

const NewCaseModal: React.FC<NewCaseModalProps> = ({ onClose, onAddTicket, customer, customerTools, users }) => {
    const [subject, setSubject] = useState('');
    const [requester, setRequester] = useState('');
    const [module, setModule] = useState<Module>(Module.SOD);
    const [status, setStatus] = useState<Status>(Status.NEW);
    const [toolSerialNumber, setToolSerialNumber] = useState('');
    const [assignee, setAssignee] = useState(CURRENT_USER.name);

    useEffect(() => {
        if (customer) {
            setRequester(customer.name);
        }
    }, [customer]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!subject || !requester) {
            alert('Please fill out Subject and Requester fields.');
            return;
        }
        onAddTicket({
            subject,
            requester,
            module,
            status,
            assignee,
            customerId: customer?.id,
            toolSerialNumber: toolSerialNumber || undefined,
        });
    }

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex flex-col justify-end sm:items-center sm:justify-center z-50"
            onClick={onClose}
        >
            <div 
                className="bg-gray-800 border-t sm:border border-gray-700 rounded-t-lg sm:rounded-lg shadow-xl p-8 w-full sm:max-w-2xl animate-slide-up sm:animate-none"
                onClick={(e) => e.stopPropagation()}
            >
                <form onSubmit={handleSubmit}>
                    <h2 className="text-2xl font-bold text-white mb-6">
                        {customer ? `New Case for ${customer.name}` : 'Create New Case'}
                    </h2>
                    
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-1">Subject</label>
                            <input 
                                type="text"
                                id="subject"
                                value={subject}
                                onChange={(e) => setSubject(e.target.value)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="requester" className="block text-sm font-medium text-gray-300 mb-1">Requester</label>
                            <input 
                                type="text"
                                id="requester"
                                value={requester}
                                onChange={(e) => setRequester(e.target.value)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                required
                                disabled={!!customer}
                            />
                        </div>

                         <div>
                            <label htmlFor="assignee" className="block text-sm font-medium text-gray-300 mb-1">Assignee</label>
                            <select 
                                id="assignee"
                                value={assignee}
                                onChange={(e) => setAssignee(e.target.value)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                            >
                                {users.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                            </select>
                        </div>

                        {customerTools && customerTools.length > 0 && (
                             <div>
                                <label htmlFor="tool" className="block text-sm font-medium text-gray-300 mb-1">Link to Tool</label>
                                <select 
                                    id="tool"
                                    value={toolSerialNumber}
                                    onChange={(e) => setToolSerialNumber(e.target.value)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                >
                                    <option value="">-- Select a tool --</option>
                                    {customerTools.map(tool => (
                                        <option key={tool.serialNumber} value={tool.serialNumber}>
                                            {tool.model} - {tool.serialNumber}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="module" className="block text-sm font-medium text-gray-300 mb-1">Module</label>
                                <select 
                                    id="module"
                                    value={module}
                                    onChange={(e) => setModule(e.target.value as Module)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                >
                                    {MODULES.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="status" className="block text-sm font-medium text-gray-300 mb-1">Status</label>
                                <select 
                                    id="status"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value as Status)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                >
                                    {STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-4 mt-8">
                        <button type="button" onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded transition">
                            Cancel
                        </button>
                        <button type="submit" className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded transition">
                            Create Case
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default NewCaseModal;