import React from 'react';
import type { TicketUpdate } from '../types';

interface TicketUpdateCardProps {
  update: TicketUpdate;
}

const TicketUpdateCard: React.FC<TicketUpdateCardProps> = ({ update }) => {
  return (
    <div className="bg-gray-900/50 border border-gray-700 rounded-md shadow-sm">
      <div className="bg-gray-700/50 px-4 py-2 border-b border-gray-700 flex justify-between items-center text-xs">
        <span className="font-bold text-red-400">{update.author}</span>
        <div className="flex items-center space-x-4">
            <span className="text-gray-400">{update.timestamp}</span>
        </div>
      </div>
      <div 
        className="p-4 text-sm text-gray-300"
        dangerouslySetInnerHTML={{ __html: update.content }}
      >
      </div>
    </div>
  );
};

export default TicketUpdateCard;