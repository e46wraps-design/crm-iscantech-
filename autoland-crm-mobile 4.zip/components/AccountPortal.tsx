

import React from 'react';
import type { Customer, Ticket, Tool } from '../types';
import AccountList from './AccountList';
import AccountDetail from './AccountDetail';

interface AccountPortalProps {
  customers: Customer[];
  tickets: Ticket[];
  tools: Tool[];
  selectedCustomer: Customer | null;
  onSelectCustomer: (customer: Customer | null) => void;
  onNewCaseForCustomer: () => void;
  onUpdateCustomer: (customer: Customer) => void;
  onAddNewTool: () => void;
}

const AccountPortal: React.FC<AccountPortalProps> = ({ 
    customers, 
    tickets, 
    tools, 
    selectedCustomer, 
    onSelectCustomer,
    onNewCaseForCustomer,
    onUpdateCustomer,
    onAddNewTool
}) => {
  return (
    <div className="p-4 sm:p-6">
    {selectedCustomer ? (
// FIX: Removed the `onGoBack` prop from `AccountDetail` as it's not a valid prop. Back navigation is handled by the global header.
        <AccountDetail 
            customer={selectedCustomer}
            tickets={tickets.filter(t => t.customerId === selectedCustomer.id)}
            tools={tools.filter(t => t.customerId === selectedCustomer.id)}
            onNewCase={onNewCaseForCustomer}
            onUpdateCustomer={onUpdateCustomer}
            onAddNewTool={onAddNewTool}
        />
        ) : (
        <AccountList 
            customers={customers}
            onSelectCustomer={onSelectCustomer}
        />
    )}
    </div>
  );
};

export default AccountPortal;