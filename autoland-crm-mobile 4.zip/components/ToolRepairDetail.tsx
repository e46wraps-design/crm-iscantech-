import React, { useState, useMemo, useEffect, useReducer, useRef } from 'react';
import type { Ticket, Part, User, LoanerTool } from '../types';
import { Status, LoanerToolStatus } from '../types';
import { STATUSES, Icons } from '../constants';
import PartsTracker from './PartsTracker';

// Reducer for parts state management
type PartsAction =
  | { type: 'SET_PARTS'; payload: Part[] }
  | { type: 'ADD_PART' }
  | { type: 'REMOVE_PART'; payload: { index: number } }
  | { type: 'CHANGE_PART'; payload: { index: number; field: keyof Part; value: string | number } };

const partsReducer = (state: Part[], action: PartsAction): Part[] => {
  switch (action.type) {
    case 'SET_PARTS':
      return action.payload;
    case 'ADD_PART':
      return [
        ...state,
        { id: `new-${Date.now()}`, name: '', partNumber: '', quantity: 1, cost: 0 },
      ];
    case 'REMOVE_PART':
      return state.filter((_, i) => i !== action.payload.index);
    case 'CHANGE_PART':
      return state.map((part, i) =>
        i === action.payload.index
          ? { ...part, [action.payload.field]: action.payload.value }
          : part
      );
    default:
      return state;
  }
};


// Sub-components for structure and reusability
const InfoCard: React.FC<{ title: string; children: React.ReactNode; rightHeaderContent?: React.ReactNode }> = ({ title, children, rightHeaderContent }) => (
  <div className="bg-gray-800 border border-gray-700 rounded-md shadow-md">
    <div className="bg-gray-700/50 px-4 py-2 border-b border-gray-700 flex justify-between items-center">
      <h3 className="font-bold text-sm text-gray-300 flex items-center">
        <span className="w-2 h-2 bg-gray-500 rounded-full mr-2"></span>
        {title}
      </h3>
      <div>{rightHeaderContent}</div>
    </div>
    <div className="p-4">{children}</div>
  </div>
);

const DetailItem: React.FC<{ 
    label: string; 
    name?: string; 
    value: any; 
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void; 
    isEditable?: boolean; 
    children?: React.ReactNode 
}> = ({ label, name, value, onChange, isEditable = true, children }) => {
    const content = isEditable ? (
        <input
            type="text"
            name={name}
            value={value}
            onChange={onChange}
            className="w-full bg-gray-900/80 border border-gray-600/50 rounded-md p-2 text-gray-200 focus:ring-red-500 focus:border-red-500"
        />
    ) : (
        <div className="bg-gray-900/80 border border-gray-600/50 rounded-md p-2 text-gray-200 min-h-[38px] flex items-center">
            {children || value}
        </div>
    );
    return (
        <div className="grid grid-cols-3 gap-2 items-center text-sm mb-2">
            <label className="text-gray-400 font-semibold col-span-1 text-right pr-2">{label}</label>
            <div className="col-span-2">
                {content}
            </div>
        </div>
    );
};

const FormSelect: React.FC<{ 
    label: string; 
    name: string; 
    value: string; 
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; 
    options: { value: string; label: string }[] | string[] 
}> = ({ label, name, value, onChange, options }) => (
    <div className="grid grid-cols-3 gap-2 items-center text-sm mb-2">
        <label className="text-gray-400 font-semibold col-span-1 text-right pr-2">{label}</label>
        <select name={name} value={value} onChange={onChange} className="col-span-2 bg-gray-900/80 border border-gray-600/50 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500">
            {options.map(opt => 
                typeof opt === 'string' 
                ? <option key={opt} value={opt}>{opt}</option>
                : <option key={opt.value} value={opt.value}>{opt.label}</option>
            )}
        </select>
    </div>
);

interface ToolRepairDetailProps {
  ticket: Ticket;
  users: User[];
  loanerTools: LoanerTool[];
  onGoBack: () => void;
  onUpdateTicket: (ticket: Ticket) => void;
}

const ToolRepairDetail: React.FC<ToolRepairDetailProps> = ({ ticket, users, loanerTools, onGoBack, onUpdateTicket }) => {
    const getInitialState = (ticket: Ticket) => {
        const details = ticket.toolRepairDetails;
        return {
            subject: ticket.subject,
            status: ticket.status,
            assignee: ticket.assignee || '',
            loanerToolId: ticket.loanerToolId || '',
            technicianNotes: details?.technicianNotes || '',
            program: details?.program || '',
            ccServices: details?.ccServices || '',
            tool: details?.tool || '',
            serialNumber: details?.serialNumber || '',
            budgetType: details?.budgetType || '',
            onHoldTill: details?.onHoldTill || '',
            distributor: details?.distributor || '',
            supportContact: details?.supportContact || '',
            billContact: details?.billContact || '',
            shipContact: details?.shipContact || '',
            caseNotes: details?.caseNotes || '',
            dateSent: details?.dateSent || '',
            sensorSN: details?.sensorSN || '',
        };
    };

    const [formState, setFormState] = useState(getInitialState(ticket));
    const [parts, dispatchParts] = useReducer(partsReducer, ticket.toolRepairDetails?.partsUsed || []);
    const technicianNotesRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        setFormState(getInitialState(ticket));
        dispatchParts({ type: 'SET_PARTS', payload: ticket.toolRepairDetails?.partsUsed || [] });
    }, [ticket]);

    const handlePartChange = (index: number, field: keyof Part, value: string | number) => {
        dispatchParts({ type: 'CHANGE_PART', payload: { index, field, value } });
    };

    const addPart = () => dispatchParts({ type: 'ADD_PART' });
    const removePart = (index: number) => dispatchParts({ type: 'REMOVE_PART', payload: { index } });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const applyFormat = (format: 'b' | 'i' | 'u' | 'ul') => {
        const textarea = technicianNotesRef.current;
        if (!textarea) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = textarea.value.substring(start, end);

        let formattedText = '';
        if (format === 'ul') {
            const lines = selectedText.split('\n').filter(line => line.trim() !== '');
            if (lines.length > 0) {
                const listItems = lines.map(line => `\t<li>${line}</li>`).join('\n');
                formattedText = `<ul>\n${listItems}\n</ul>`;
            } else if (selectedText.trim()) {
                formattedText = `<ul>\n\t<li>${selectedText.trim()}</li>\n</ul>`;
            } else {
                return; // No text selected or just whitespace
            }
        } else {
            formattedText = `<${format}>${selectedText}</${format}>`;
        }

        const newValue = 
            textarea.value.substring(0, start) + 
            formattedText + 
            textarea.value.substring(end);

        setFormState(prev => ({ ...prev, technicianNotes: newValue }));

        // After state update, focus textarea and set cursor position.
        // Using setTimeout to allow React to re-render first.
        setTimeout(() => {
            if (technicianNotesRef.current) {
                technicianNotesRef.current.focus();
                const newCursorPos = start + formattedText.length;
                technicianNotesRef.current.setSelectionRange(newCursorPos, newCursorPos);
            }
        }, 0);
    };

    const handleSave = (close: boolean, finalStatus?: Status) => {
        const { subject, status, assignee, loanerToolId, technicianNotes, program, ccServices, tool, serialNumber, budgetType, onHoldTill, distributor, supportContact, billContact, shipContact, caseNotes, dateSent, sensorSN } = formState;

        const updatedTicket: Ticket = {
            ...ticket,
            subject,
            status: finalStatus || (status as Status),
            assignee: assignee || undefined,
            loanerToolId: loanerToolId || undefined,
            toolRepairDetails: {
                ...ticket.toolRepairDetails!,
                program, ccServices, tool, serialNumber, budgetType, onHoldTill, distributor, supportContact, billContact, shipContact, caseNotes, dateSent, sensorSN, technicianNotes,
                partsUsed: parts,
            },
            timestamp: new Date().toLocaleString() + ' (edited)',
        };

        onUpdateTicket(updatedTicket);
        alert('Ticket Saved!');

        if (close) {
            onGoBack();
        }
    };

    const availableTools = useMemo(() => {
        const allPossibleTools = loanerTools.filter(t => t.status === LoanerToolStatus.AVAILABLE);
        if (ticket.loanerToolId) {
            const currentTool = loanerTools.find(t => t.id === ticket.loanerToolId);
            if (currentTool && !allPossibleTools.some(t => t.id === currentTool.id)) {
                allPossibleTools.unshift(currentTool);
            }
        }
        const excludedTypes = ['AssistPlus', 'Pro-Series 3'];
        return allPossibleTools.filter(tool => {
            if (tool.id === ticket.loanerToolId) return true;
            return !excludedTypes.includes(tool.type);
        });
    }, [ticket.loanerToolId, loanerTools]);

    if (!ticket.toolRepairDetails) {
        return (
            <div className="p-6">
                <h2 className="text-xl text-red-500">Error: Tool repair details not found for this ticket.</h2>
                <button onClick={onGoBack} className="mt-4 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition">
                    &larr; Back to List
                </button>
            </div>
        );
    }
    
    return (
        <div className="p-6 bg-gray-900 text-gray-200 min-h-screen overflow-y-auto">
            {/* Header */}
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h1 className="text-4xl font-extrabold tracking-tight text-white">{ticket.id}</h1>
                     <input
                        type="text"
                        name="subject"
                        value={formState.subject}
                        onChange={handleChange}
                        className="text-gray-400 mt-1 bg-transparent w-full border-0 focus:ring-1 focus:ring-red-500 focus:bg-gray-700 rounded-md p-1"
                        aria-label="Ticket Subject"
                    />
                </div>
                <div className="flex items-center space-x-2">
                    <select
                        name="status"
                        value={formState.status}
                        onChange={handleChange}
                        className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-md transition border-gray-600 focus:ring-red-500 focus:border-red-500"
                        aria-label="Ticket Status"
                    >
                        {STATUSES.map(s => (
                            <option key={s.id} value={s.id}>{s.label}</option>
                        ))}
                    </select>
                    <button onClick={onGoBack} className="ml-4 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition">
                        &larr; Back
                    </button>
                </div>
            </div>

            {/* Main grid */}
            <div className="grid grid-cols-12 gap-6">
                {/* Left Column */}
                <div className="col-span-4 space-y-4">
                    <InfoCard title="Event Info">
                        <DetailItem label="Name" value={ticket.requester} isEditable={false} />
                        <DetailItem label="Program" name="program" value={formState.program} onChange={handleChange} />
                        <DetailItem label="CC Services" name="ccServices" value={formState.ccServices} onChange={handleChange} />
                        <FormSelect 
                            label="Tool" 
                            name="tool"
                            value={formState.tool} 
                            onChange={handleChange}
                            options={['vidas3', 'vidas 4', 'iscan3', 'iscan sf', 'iscan nx']} 
                        />
                        <DetailItem label="S/N" name="serialNumber" value={formState.serialNumber} onChange={handleChange} />
                        <DetailItem label="Case Created" value={new Date(ticket.createdAt).toLocaleDateString()} isEditable={false} />
                        <DetailItem label="Budget Type" name="budgetType" value={formState.budgetType} onChange={handleChange} />
                        <DetailItem label="On Hold Till" name="onHoldTill" value={formState.onHoldTill} onChange={handleChange} />
                        <DetailItem label="Distributor" name="distributor" value={formState.distributor} onChange={handleChange} />
                    </InfoCard>
                    <InfoCard title="Contact Info">
                        <DetailItem label="Support" name="supportContact" value={formState.supportContact} onChange={handleChange} />
                        <DetailItem label="Bill" name="billContact" value={formState.billContact} onChange={handleChange} />
                        <DetailItem label="Ship" name="shipContact" value={formState.shipContact} onChange={handleChange} />
                        <DetailItem label="Case Notes" name="caseNotes" value={formState.caseNotes} onChange={handleChange} />
                        <DetailItem label="Date Sent" name="dateSent" value={formState.dateSent} onChange={handleChange} />
                        <DetailItem label="Sensor S/N" name="sensorSN" value={formState.sensorSN} onChange={handleChange} />
                    </InfoCard>
                    <button onClick={() => handleSave(true)} className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-lg transition text-sm">
                        SAVE TICKET & CLOSE WINDOW
                    </button>
                </div>

                {/* Right Column */}
                <div className="col-span-8 space-y-4">
                    <InfoCard title="General Fields Contact not listed on this ticket">
                        <DetailItem label="To Team" value="Technical (US)" isEditable={false}/>
                        <DetailItem label="Case Notes" value={ticket.symptom || 'N/A'} isEditable={false}/>
                    </InfoCard>
                    <InfoCard title="Technician">
                         <FormSelect 
                            label="Technician" 
                            name="assignee" 
                            value={formState.assignee} 
                            onChange={handleChange} 
                            options={[{value: '', label: '-- Unassigned --'}, ...users.map(u => ({ value: u.name, label: u.name })) ]}
                        />
                    </InfoCard>
                    <InfoCard title="Assign Loaner Tool">
                        <div className="flex items-center space-x-4">
                            <div className="flex-1">
                                <label htmlFor="loaner-tool-select-repair" className="text-xs font-semibold text-gray-400 mb-1 block">
                                    Available Tools
                                </label>
                                <select
                                    id="loaner-tool-select-repair"
                                    name="loanerToolId"
                                    value={formState.loanerToolId}
                                    onChange={handleChange}
                                    className="w-full bg-gray-900/80 border border-gray-600/50 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                >
                                    <option value="">-- No loaner assigned --</option>
                                    {availableTools.map(tool => (
                                        <option key={tool.id} value={tool.id}>
                                            {tool.type} - {tool.serialNumber} ({tool.status})
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <button onClick={() => handleSave(false)} className="self-end bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded-md transition text-sm">
                                Save
                            </button>
                        </div>
                    </InfoCard>
                    <InfoCard title="Internal Ticket">
                        <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                             <DetailItem label="SC/N" value="000" isEditable={false}/>
                             <DetailItem label="CC Service" value="00" isEditable={false}/>
                             <DetailItem label="S/N" value="Sample S/N" isEditable={false}/>
                             <DetailItem label="Due Date" value={ticket.dueDate ? new Date(ticket.dueDate).toLocaleDateString() : 'N/A'} isEditable={false} />
                             <FormSelect label="Status" name="status" value={formState.status} onChange={handleChange} options={['New', 'In Progress', 'Call completed']} />
                        </div>
                    </InfoCard>
                     <InfoCard title="Technician Notes">
                        <div className="border border-gray-600 rounded-md">
                            <div className="flex items-center space-x-2 p-2 bg-gray-700/50 border-b border-gray-600">
                                <button onClick={() => applyFormat('b')} title="Bold" className="px-3 py-1 text-sm font-bold bg-gray-600 hover:bg-gray-500 rounded">B</button>
                                <button onClick={() => applyFormat('i')} title="Italic" className="px-3 py-1 text-sm italic bg-gray-600 hover:bg-gray-500 rounded">I</button>
                                <button onClick={() => applyFormat('u')} title="Underline" className="px-3 py-1 text-sm underline bg-gray-600 hover:bg-gray-500 rounded">U</button>
                                <button onClick={() => applyFormat('ul')} title="Bulleted List" className="px-3 py-1 text-sm bg-gray-600 hover:bg-gray-500 rounded">List</button>
                            </div>
                            <textarea
                                ref={technicianNotesRef}
                                className="w-full h-32 p-2 bg-gray-900/80 text-gray-200 resize-y focus:outline-none"
                                name="technicianNotes"
                                value={formState.technicianNotes}
                                onChange={handleChange}
                                aria-label="Technician Notes"
                            />
                        </div>
                    </InfoCard>
                    <InfoCard 
                        title="Parts Tracker"
                        rightHeaderContent={
                            <button onClick={addPart} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-1 px-3 rounded-md transition text-xs flex items-center">
                                <div className="w-4 h-4">{Icons.plus}</div>
                                <span className="ml-2">Add Part</span>
                            </button>
                        }
                    >
                        <PartsTracker
                            parts={parts}
                            onPartChange={handlePartChange}
                            onRemovePart={removePart}
                        />
                    </InfoCard>
                     <div className="flex justify-end">
                        <button onClick={() => handleSave(true, Status.CALL_COMPLETED)} className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded-lg transition">
                            Submit to Final Bill/Close Case
                        </button>
                    </div>
                    {/* Log */}
                     <div className="bg-gray-800 border border-gray-700 rounded-md">
                        {ticket.updates.map((update, index) => (
                            <div key={update.id} className={`p-4 border-b border-gray-700 last:border-b-0 ${index % 2 !== 0 ? 'bg-yellow-900/10' : ''}`}>
                                <div className="flex justify-between items-center text-xs text-gray-400 mb-1">
                                    <span>Event {index + 1} by <span className="font-bold text-red-400">{update.author}</span></span>
                                    <span>{update.timestamp}</span>
                                 </div>
                                <p className="text-sm text-gray-200">{update.content}</p>
                            </div>
                        ))}
                         {ticket.updates.length === 0 && <div className="p-4 text-sm text-gray-500">No updates for this ticket yet.</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ToolRepairDetail;