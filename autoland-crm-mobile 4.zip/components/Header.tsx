import React from 'react';

interface HeaderProps {
  title: string;
  showBack: boolean;
  onBack: () => void;
}

const Header: React.FC<HeaderProps> = ({ title, showBack, onBack }) => {
  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4 z-50 print:hidden">
      <div className="w-10">
        {showBack && (
          <button
            onClick={onBack}
            className="text-white font-bold p-2 rounded-full hover:bg-gray-700 transition"
            aria-label="Go back"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        )}
      </div>
      <h1 className="text-lg font-bold text-white truncate text-center">{title}</h1>
      <div className="w-10"></div> {/* Spacer to keep title centered */}
    </header>
  );
};

export default Header;
