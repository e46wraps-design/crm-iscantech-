import React, { useState, useMemo } from 'react';
import type { FilterState } from '../types';
import { Status, Brand } from '../types';

interface SidebarProps {
  statuses: { id: Status, label: string }[];
  brands: { id: Brand, label: string }[];
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onClearFilters: () => void;
}

const FilterSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-6">
    <h3 className="text-xs font-bold uppercase text-gray-500 mb-3 px-2">{title}</h3>
    <div className="space-y-2">{children}</div>
  </div>
);

const Checkbox: React.FC<{ label: string; checked: boolean; onChange: (checked: boolean) => void }> = ({ label, checked, onChange }) => (
  <label className="flex items-center text-sm text-gray-300 hover:bg-gray-700 px-2 py-1 rounded cursor-pointer transition">
    <input
      type="checkbox"
      className="h-4 w-4 rounded bg-gray-700 border-gray-600 text-red-600 focus:ring-red-500"
      checked={checked}
      onChange={e => onChange(e.target.checked)}
    />
    <span className="ml-3">{label}</span>
  </label>
);

const Sidebar: React.FC<SidebarProps> = ({ statuses, brands, filters, onFilterChange, onClearFilters }) => {
  const [brandSearch, setBrandSearch] = useState('');

  const filteredBrands = useMemo(() => {
    if (!brandSearch.trim()) {
      return brands;
    }
    const lowercasedSearch = brandSearch.toLowerCase();
    return brands.filter(brand =>
      brand.label.toLowerCase().includes(lowercasedSearch)
    );
  }, [brands, brandSearch]);

  const handleCheckboxChange = <T extends Status | Brand>(key: keyof Omit<FilterState, 'assignedToMe' | 'searchTerm'>, value: T) => {
    const currentValues = filters[key] as T[];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    onFilterChange({ ...filters, [key]: newValues });
  };

  const handleAssignedToMeChange = (checked: boolean) => {
     onFilterChange({ ...filters, assignedToMe: checked });
  };

  return (
    <div className="w-full sm:w-64 bg-gray-800 p-4 flex-shrink-0 max-h-[70vh] overflow-y-auto">
      <FilterSection title="Status">
        {statuses.map(s => (
          <Checkbox 
            key={s.id}
            label={s.label}
            checked={filters.statuses.includes(s.id)}
            onChange={() => handleCheckboxChange('statuses', s.id)}
          />
        ))}
      </FilterSection>
      
      <div className="my-4 border-t border-gray-700"></div>

      <Checkbox
        label="Assigned To me"
        checked={filters.assignedToMe}
        onChange={handleAssignedToMeChange}
      />
      
      <div className="my-4 border-t border-gray-700"></div>

      <FilterSection title="Ticket Brand">
        <div className="px-2">
            <input
              type="search"
              placeholder="Search brands..."
              value={brandSearch}
              onChange={e => setBrandSearch(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-md py-1 px-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
              aria-label="Search ticket brands"
            />
        </div>
        <div className="grid grid-cols-2 gap-2">
            {filteredBrands.map(b => (
              <Checkbox 
                key={b.id}
                label={b.label}
                checked={filters.brands.includes(b.id)}
                onChange={() => handleCheckboxChange('brands', b.id)}
              />
            ))}
             {filteredBrands.length === 0 && (
              <p className="text-xs text-gray-500 col-span-2 text-center px-2">No brands found.</p>
            )}
        </div>
      </FilterSection>
      
      <div className="my-4 border-t border-gray-700"></div>

      <button
          onClick={onClearFilters}
          className="w-full text-center text-sm bg-gray-700 hover:bg-gray-600 text-gray-300 font-semibold py-2 px-4 rounded-md transition"
      >
          Clear All Filters
      </button>
    </div>
  );
};

export default Sidebar;