import React from 'react';
// FIX: Import SortConfig and TicketSortKey to use centralized types.
import type { Ticket, FilterState, SortConfig, TicketSortKey, User } from '../types';
import { Icons } from '../constants';
import TicketListItem from './TicketListItem';

// FIX: Removed local type definitions for SortConfig and TicketSortKey. They are now imported from types.ts.

interface TicketListProps {
  tickets: Ticket[];
  onSelectTicket: (ticketId: string) => void;
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onFilterToggle: () => void;
  isFilterActive: boolean;
  sortConfig: SortConfig;
  onSortChange: (config: SortConfig) => void;
  users: User[];
  onUpdateTicket: (ticket: Ticket) => void;
}

const TicketList: React.FC<TicketListProps> = ({ tickets, onSelectTicket, filters, onFilterChange, onFilterToggle, isFilterActive, sortConfig, onSortChange, users, onUpdateTicket }) => {
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, searchTerm: e.target.value });
  };

  const handleSortKeyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onSortChange({ ...sortConfig, key: e.target.value as TicketSortKey });
  };

  const toggleSortDirection = () => {
    onSortChange({ ...sortConfig, direction: sortConfig.direction === 'asc' ? 'desc' : 'asc' });
  };

  const sortOptions: { value: TicketSortKey; label: string }[] = [
    { value: 'createdAt', label: 'Last Updated' },
    { value: 'dueDate', label: 'Due Date' },
    { value: 'id', label: 'Ticket ID' },
    { value: 'subject', label: 'Subject' },
    { value: 'requester', label: 'Requester' },
    { value: 'assignee', label: 'Assignee' },
    { value: 'status', label: 'Status' },
  ];

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 gap-4">
        <div className="flex items-center gap-4">
             <button 
                onClick={onFilterToggle}
                className="relative flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-md transition"
             >
                {Icons.filter}
                <span>Filters</span>
                {isFilterActive && (
                    <span className="absolute -top-1 -right-1 block h-3 w-3 rounded-full bg-red-500 border-2 border-gray-800" aria-label="Filters active"></span>
                )}
             </button>
             <span className="text-gray-400" aria-live="polite" role="status">
                {tickets.length} {tickets.length === 1 ? 'result' : 'results'}
             </span>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-start sm:justify-end">
            <div className="flex items-center gap-2">
                <label htmlFor="sort-by" className="text-sm text-gray-400 flex-shrink-0">Sort by:</label>
                <select
                    id="sort-by"
                    value={sortConfig.key}
                    onChange={handleSortKeyChange}
                    className="bg-gray-700 border border-gray-600 rounded-md py-2 pl-3 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                    aria-label="Sort tickets by"
                >
                    {sortOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
                <button
                    onClick={toggleSortDirection}
                    className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-3 rounded-md transition"
                    aria-label="Toggle sort direction"
                >
                    {sortConfig.direction === 'asc' ? '↑' : '↓'}
                </button>
            </div>
            <div className="relative">
                <input 
                  type="search" 
                  placeholder="Search cases..."
                  aria-label="Search cases by ID, Subject, Requester, symptom, or response"
                  value={filters.searchTerm}
                  onChange={handleSearchChange}
                  className="bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-red-500 w-full sm:w-64"
                  aria-controls="ticket-list-container"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  {Icons.search}
                </div>
            </div>
        </div>
      </div>
       <div id="ticket-list-container" className="space-y-4">
        {tickets.length > 0 ? (
            tickets.map(ticket => (
                <TicketListItem 
                    key={ticket.id} 
                    ticket={ticket} 
                    onSelectTicket={onSelectTicket} 
                    searchTerm={filters.searchTerm}
                    users={users}
                    onUpdateTicket={onUpdateTicket}
                />
            ))
        ) : (
             <div className="text-center py-10 text-gray-500 bg-gray-800 rounded-lg">
                <p>No tickets match the current filters.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default TicketList;