import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Ticket, Status, User, Customer, LoanerTool } from '../types';
import VehicleDetails from './VehicleDetails';
import TicketUpdateCard from './TicketUpdateCard';
import CaseStatus from './CaseStatus';
import { Module, LoanerToolStatus } from '../types';
import ToolRepairDetail from './ToolRepairDetail';
import { Icons, CURRENT_USER } from '../constants';

interface TicketDetailProps {
  ticket: Ticket;
  users: User[];
  customers: Customer[];
  loanerTools: LoanerTool[];
  onUpdateTicket: (ticket: Ticket) => void;
  onDeleteTicket: (ticketId: string) => void;
  currentUser: User;
}

const InfoCard: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; className?: string; }> = ({ title, icon, children, className }) => (
    <div className={`bg-gray-800/50 border border-gray-700/50 rounded-lg shadow-md ${className}`}>
        <div className="flex items-center p-3 border-b border-gray-700/50">
            <div className="w-5 h-5 mr-2 text-gray-400">{icon}</div>
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider">{title}</h3>
        </div>
        <div className="p-4">{children}</div>
    </div>
);

const SmsModal: React.FC<{ customer: Customer; ticketId: string; onClose: () => void; }> = ({ customer, ticketId, onClose }) => {
    const [message, setMessage] = useState(`Hi ${customer.name.split(' ')[0]}, this is regarding ticket ${ticketId}.`);
    const [isSent, setIsSent] = useState(false);

    const handleSend = () => {
        console.log(`
        --- ZOHO SMS SIMULATION ---
        TO: ${customer.phone}
        MESSAGE: ${message}
        ---------------------------
        `);
        setIsSent(true);
        setTimeout(() => {
            onClose();
        }, 1500);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
                <h3 className="text-lg font-bold text-white mb-4">Send SMS to {customer.name}</h3>
                <p className="text-sm text-gray-400 mb-1">To: {customer.phone}</p>
                <p className="text-sm text-gray-400 mb-4">Re: Ticket {ticketId}</p>
                <textarea
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    className="w-full h-32 bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300 resize-y focus:outline-none focus:ring-1 focus:ring-red-500"
                    aria-label="SMS message content"
                />
                <div className="flex justify-end space-x-3 mt-4">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded transition text-sm">Cancel</button>
                    <button onClick={handleSend} className={`font-bold py-2 px-4 rounded transition text-sm text-white ${isSent ? 'bg-green-600' : 'bg-red-600 hover:bg-red-700'}`} disabled={isSent}>
                        {isSent ? 'Sent!' : 'Send Message'}
                    </button>
                </div>
            </div>
        </div>
    );
};

const TicketDetail: React.FC<TicketDetailProps> = ({ ticket, users, customers, loanerTools, onUpdateTicket, onDeleteTicket, currentUser }) => {
  const [subject, setSubject] = useState(ticket.subject);
  const [symptom, setSymptom] = useState(ticket.symptom || '');
  const [response, setResponse] = useState(ticket.response || '');
  const [privateNotes, setPrivateNotes] = useState(ticket.privateNotes || '');
  const [teamViewerId, setTeamViewerId] = useState(ticket.teamViewerId || '');
  const [teamViewerPassword, setTeamViewerPassword] = useState(ticket.teamViewerPassword || '');
  const [selectedToolId, setSelectedToolId] = useState(ticket.loanerToolId || '');
  const [status, setStatus] = useState<Status>(ticket.status);
  const [assignee, setAssignee] = useState(ticket.assignee || '');
  const [isSmsModalOpen, setIsSmsModalOpen] = useState(false);
  const [copiedField, setCopiedField] = useState<'id' | 'pass' | null>(null);
  
  const [newUpdateContent, setNewUpdateContent] = useState('');
  const newUpdateTextareaRef = useRef<HTMLTextAreaElement>(null);
  const [newAttachments, setNewAttachments] = useState<File[]>([]);
  const [callbackDateTime, setCallbackDateTime] = useState('');
  const [reminderDateTime, setReminderDateTime] = useState('');

  const customer = useMemo(() => customers.find(c => c.id === ticket.customerId), [customers, ticket.customerId]);

  useEffect(() => {
    setSubject(ticket.subject);
    setSymptom(ticket.symptom || '');
    setResponse(ticket.response || '');
    setPrivateNotes(ticket.privateNotes || '');
    setTeamViewerId(ticket.teamViewerId || '');
    setTeamViewerPassword(ticket.teamViewerPassword || '');
    setSelectedToolId(ticket.loanerToolId || '');
    setStatus(ticket.status);
    setAssignee(ticket.assignee || '');
    setCallbackDateTime(ticket.callbackScheduledAt ? ticket.callbackScheduledAt.slice(0, 16) : '');
    setReminderDateTime(ticket.reminderAt ? ticket.reminderAt.slice(0, 16) : '');
    setNewUpdateContent('');
    setNewAttachments([]);
  }, [ticket]);
  
  const handleDelete = () => {
      if(window.confirm(`Are you sure you want to delete ticket ${ticket.id}?`)) {
          onDeleteTicket(ticket.id);
      }
  }
  
  const handleCopyToClipboard = (text: string, field: 'id' | 'pass') => {
      navigator.clipboard.writeText(text).then(() => {
          setCopiedField(field);
          setTimeout(() => setCopiedField(null), 2000);
      }, (err) => {
          console.error('Failed to copy text: ', err);
          alert('Failed to copy text.');
      });
  };

  const handleSave = (close: boolean) => {
    const newUpdates = [...ticket.updates];
    if (newUpdateContent.trim()) {
      newUpdates.unshift({
        id: `update-${Date.now()}`,
        author: CURRENT_USER.name,
        timestamp: new Date().toLocaleString(),
        content: newUpdateContent,
      });
    }

    const combinedAttachments = [
      ...(ticket.attachments || []),
      ...newAttachments.map(file => ({ name: file.name, url: '#' }))
    ];

    const updatedTicket: Ticket = {
      ...ticket,
      subject,
      symptom,
      response,
      privateNotes,
      teamViewerId,
      teamViewerPassword,
      status,
      assignee,
      loanerToolId: selectedToolId,
      timestamp: new Date().toLocaleString() + ' (edited)',
      updates: newUpdates,
      attachments: combinedAttachments.length > 0 ? combinedAttachments : undefined,
      callbackScheduledAt: callbackDateTime ? new Date(callbackDateTime).toISOString() : undefined,
      reminderAt: reminderDateTime ? new Date(reminderDateTime).toISOString() : undefined,
    };
    onUpdateTicket(updatedTicket);
    if(close) {
        // The onGoBack prop is removed, this might need adjustment if save&close is a hard requirement.
        // For now, it just saves. The user can use the global back button.
        alert('Ticket Saved!');
    }
  };

  const applyFormat = (format: 'b' | 'i' | 'ul') => {
    const textarea = newUpdateTextareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);

    if (format === 'ul') {
      const lines = selectedText.split('\n').filter(line => line.trim() !== '');
      if(lines.length === 0) return;
      const listItems = lines.map(line => `\t<li>${line}</li>`).join('\n');
      const formattedText = `<ul>\n${listItems}\n</ul>`;
      setNewUpdateContent(textarea.value.substring(0, start) + formattedText + textarea.value.substring(end));
    } else {
      const formattedText = `<${format}>${selectedText}</${format}>`;
      setNewUpdateContent(textarea.value.substring(0, start) + formattedText + textarea.value.substring(end));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setNewAttachments(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };


  const availableTools = useMemo(() => {
    const currentTool = loanerTools.find(t => t.id === ticket.loanerToolId);
    const available = loanerTools.filter(t => t.status === LoanerToolStatus.AVAILABLE);
    const combined = [...available];
    if (currentTool && !available.some(t => t.id === currentTool.id)) {
        combined.unshift(currentTool);
    }
    return combined;
  }, [loanerTools, ticket.loanerToolId]);

  if (ticket.module === Module.TOOL_REPAIR) {
    return <ToolRepairDetail ticket={ticket} onGoBack={() => {}} onUpdateTicket={onUpdateTicket} users={users} loanerTools={loanerTools} />;
  }
  
  const renderStatusPill = (status: Customer['subscriptionStatus'] | Customer['liveStatus']) => {
    const colors = {
        'Active': 'bg-green-500/80 text-green-100',
        'Online': 'bg-green-500/80 text-green-100',
        'Expired': 'bg-red-500/80 text-red-100',
        'Offline': 'bg-gray-500 text-gray-100',
        'Trial': 'bg-blue-500/80 text-blue-100',
        'Away': 'bg-yellow-500/80 text-yellow-100',
        'None': 'bg-gray-500 text-gray-100'
    };
    return <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${colors[status] || 'bg-gray-600'}`}>{status}</span>;
  };


  return (
    <div className="flex flex-col lg:flex-row h-full bg-gray-900">
      {isSmsModalOpen && customer && <SmsModal customer={customer} ticketId={ticket.id} onClose={() => setIsSmsModalOpen(false)} />}
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col p-4 sm:p-6 overflow-y-auto">
        <div className="flex-1 bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-4">
            <div>
              <label htmlFor="ticket-subject" className="text-sm font-bold text-gray-400 mb-1 block">Subject</label>
              <input
                  id="ticket-subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full text-lg font-bold text-white bg-gray-700 border border-gray-600 rounded-md p-2"
                  aria-label="Ticket Subject"
              />
            </div>
          <div className="bg-gray-900/50 border border-gray-700 rounded-md shadow-sm p-4">
              <h4 className="text-sm font-bold text-gray-400 mb-2">Symptom</h4>
              <textarea 
                value={symptom}
                onChange={(e) => setSymptom(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300 resize-y" 
                rows={3}
              />
          </div>
          <div className="bg-gray-900/50 border border-gray-700 rounded-md shadow-sm p-4">
              <h4 className="text-sm font-bold text-gray-400 mb-2">Response</h4>
              <textarea 
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300 resize-y" 
                rows={3}
              />
          </div>
          
          <div className="bg-gray-900/50 border border-gray-700 rounded-md shadow-sm p-4">
            <h4 className="text-sm font-bold text-gray-400 mb-2">Add Update</h4>
            <div className="flex items-center space-x-2 p-2 bg-gray-700/50 border-b border-gray-600 rounded-t-md">
                <button onClick={() => applyFormat('b')} title="Bold" className="px-3 py-1 text-sm font-bold bg-gray-600 hover:bg-gray-500 rounded">B</button>
                <button onClick={() => applyFormat('i')} title="Italic" className="px-3 py-1 text-sm italic bg-gray-600 hover:bg-gray-500 rounded">I</button>
                <button onClick={() => applyFormat('ul')} title="Bulleted List" className="px-3 py-1 text-sm bg-gray-600 hover:bg-gray-500 rounded">List</button>
            </div>
            <textarea 
                ref={newUpdateTextareaRef}
                value={newUpdateContent}
                onChange={(e) => setNewUpdateContent(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 border-t-0 rounded-b-md p-2 text-sm text-gray-300 resize-y" 
                rows={4}
                placeholder="Add a new public update with formatting..."
            />
          </div>

          {ticket.updates.length > 0 && <h4 className="text-sm font-bold text-gray-400 pt-4 border-t border-gray-700">Updates</h4>}
          {ticket.updates.map(update => (
            <TicketUpdateCard key={update.id} update={update} />
          ))}
        </div>
        
        <div className="mt-6">
          <CaseStatus 
            onSave={handleSave} 
            status={status} 
            onStatusChange={setStatus} 
            users={users}
            assignee={assignee}
            onAssigneeChange={setAssignee}
            />
        </div>
      </div>
      
      {/* Sidebar */}
      <aside className="w-full lg:w-96 bg-gray-800/70 border-t lg:border-l lg:border-t-0 border-gray-700 p-4 sm:p-6 flex-shrink-0 space-y-6 overflow-y-auto">
        {currentUser.role === 'admin' && (
            <div className="bg-red-900/50 border border-red-700/50 rounded-lg p-4">
                <h3 className="text-sm font-bold text-red-300 uppercase mb-2">Admin Actions</h3>
                <button
                    onClick={handleDelete}
                    className="w-full bg-red-800 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition text-sm"
                >
                    Delete Ticket
                </button>
            </div>
        )}
        
        {ticket.vehicle && <VehicleDetails vehicle={ticket.vehicle} />}

        <InfoCard title="Reminder" icon={Icons.clock}>
            {reminderDateTime ? (
                <div>
                    <p className="text-lg font-semibold text-white">{new Date(reminderDateTime).toLocaleString()}</p>
                    <div className="flex justify-end space-x-2 mt-2">
                        <button onClick={() => setReminderDateTime('')} className="text-xs text-gray-400 hover:text-red-400">Clear</button>
                    </div>
                </div>
            ) : (
                 <div>
                    <p className="text-sm text-gray-400 mb-2">No reminder set.</p>
                    <input
                        type="datetime-local"
                        value={reminderDateTime}
                        onChange={e => setReminderDateTime(e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300"
                    />
                </div>
            )}
        </InfoCard>
        
        <InfoCard title="Scheduled Callback" icon={Icons.phone}>
            {callbackDateTime ? (
                <div>
                    <p className="text-lg font-semibold text-white">{new Date(callbackDateTime).toLocaleString()}</p>
                    <div className="flex justify-end space-x-2 mt-2">
                        <button onClick={() => setCallbackDateTime('')} className="text-xs text-gray-400 hover:text-red-400">Cancel</button>
                    </div>
                </div>
            ) : (
                <div>
                    <p className="text-sm text-gray-400 mb-2">No callback scheduled.</p>
                    <input
                        type="datetime-local"
                        value={callbackDateTime}
                        onChange={e => setCallbackDateTime(e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300"
                    />
                </div>
            )}
        </InfoCard>
        
        <InfoCard title="Loaner Tool" icon={Icons.settings}>
            <select
                name="loanerToolId"
                value={selectedToolId}
                onChange={(e) => setSelectedToolId(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
            >
                <option value="">-- No loaner assigned --</option>
                {availableTools.map(tool => (
                    <option key={tool.id} value={tool.id}>
                        {tool.type} - {tool.serialNumber} ({tool.status})
                    </option>
                ))}
            </select>
        </InfoCard>

        <InfoCard title="Attachments" icon={Icons.paperclip}>
            <div className="space-y-2">
                {(ticket.attachments || []).map((att, index) => (
                    <a key={index} href={att.url} className="flex items-center text-sm text-blue-400 hover:underline">
                        <div className="w-4 h-4 mr-2">{Icons.paperclip}</div> {att.name}
                    </a>
                ))}
                {newAttachments.map((file, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-300">
                        <div className="w-4 h-4 mr-2">{Icons.paperclip}</div> {file.name} <span className="text-xs text-gray-500 ml-2">(pending upload)</span>
                    </div>
                ))}
                {(!ticket.attachments || ticket.attachments.length === 0) && newAttachments.length === 0 && (
                    <p className="text-sm text-gray-500">No attachments.</p>
                )}
            </div>
            <div className="mt-4">
                <label className="w-full text-center cursor-pointer bg-gray-600 hover:bg-gray-500 text-white font-semibold py-2 px-4 rounded transition text-sm block">
                    Add Files
                    <input type="file" multiple onChange={handleFileSelect} className="hidden" />
                </label>
            </div>
        </InfoCard>

        {customer && (
            <InfoCard title="Customer Details" icon={Icons.user}>
                <h4 className="font-bold text-lg text-white">{customer.name}</h4>
                <p className="text-sm text-gray-400 mb-3">{customer.company}</p>
                <div className="flex flex-wrap gap-2 mb-4 text-xs">
                    {renderStatusPill(customer.subscriptionStatus)}
                    {renderStatusPill(customer.liveStatus)}
                </div>
                <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between gap-2">
                         <span className="flex items-center text-gray-300">
                            <div className="w-5 h-5 mr-3 text-gray-400">{Icons.phone}</div> {customer.phone}
                         </span>
                         <div className="flex-shrink-0 flex items-center gap-2">
                             <a href={`tel:${customer.phone}`} title="Call Customer" className="bg-gray-700 hover:bg-gray-600 text-white font-bold p-2 rounded-md transition text-xs"><div className="w-4 h-4">{Icons.phone}</div></a>
                             <button onClick={() => setIsSmsModalOpen(true)} title="Send SMS" className="bg-gray-700 hover:bg-gray-600 text-white font-bold p-2 rounded-md transition text-xs"><div className="w-4 h-4">{Icons.chat}</div></button>
                         </div>
                     </div>
                    <a href={`mailto:${customer.email}`} className="flex items-center text-gray-300 hover:text-red-400 transition group">
                        <div className="w-5 h-5 mr-3 text-gray-400 group-hover:text-red-400">{Icons.email}</div> {customer.email}
                    </a>
                </div>
            </InfoCard>
        )}
        
        <InfoCard title="Remote Session" icon={Icons.desktop}>
            <div className="space-y-3">
                <div>
                    <label className="text-xs text-gray-400 font-semibold block mb-1">TeamViewer ID</label>
                    <div className="flex items-center">
                        <input type="text" value={teamViewerId} onChange={(e) => setTeamViewerId(e.target.value)} className="w-full bg-gray-700 border border-gray-600 rounded-l-md p-2 text-sm focus:ring-red-500 focus:border-red-500"/>
                        <button onClick={() => handleCopyToClipboard(teamViewerId, 'id')} className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-2 rounded-r-md border border-l-0 border-gray-600 text-xs font-bold w-20 text-center">
                            {copiedField === 'id' ? 'Copied!' : 'Copy'}
                        </button>
                    </div>
                </div>
                <div>
                    <label className="text-xs text-gray-400 font-semibold block mb-1">Password</label>
                    <div className="flex items-center">
                        <input type="password" value={teamViewerPassword} onChange={(e) => setTeamViewerPassword(e.target.value)} className="w-full bg-gray-700 border border-gray-600 rounded-l-md p-2 text-sm focus:ring-red-500 focus:border-red-500"/>
                        <button onClick={() => handleCopyToClipboard(teamViewerPassword, 'pass')} className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-2 rounded-r-md border border-l-0 border-gray-600 text-xs font-bold w-20 text-center">
                            {copiedField === 'pass' ? 'Copied!' : 'Copy'}
                        </button>
                    </div>
                </div>
            </div>
        </InfoCard>
        
        <InfoCard title="Private Notes" icon={Icons.lock}>
            <textarea 
              value={privateNotes}
              onChange={(e) => setPrivateNotes(e.target.value)}
              placeholder="Add internal notes here. Not visible to the customer."
              className="w-full h-28 bg-gray-700 border border-gray-600 rounded-md p-2 text-sm text-gray-300 resize-y focus:outline-none focus:ring-1 focus:ring-red-500"
              aria-label="Private Notes"
            />
        </InfoCard>
      </aside>
    </div>
  );
};

export default TicketDetail;