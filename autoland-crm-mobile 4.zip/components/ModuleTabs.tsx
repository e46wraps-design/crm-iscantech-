import React from 'react';
import { Module } from '../types';
import { MODULES } from '../constants';

interface ModuleTabsProps {
  activeTab: Module | 'all';
  onTabSelect: (tab: Module | 'all') => void;
}

const ModuleTabs: React.FC<ModuleTabsProps> = ({ activeTab, onTabSelect }) => {
  const tabs = [{ id: 'all', label: 'All' }, ...MODULES];

  const getTabClass = (tabId: Module | 'all') => {
    const baseClasses = 'px-4 py-2 text-sm font-medium transition-colors duration-200 ease-in-out focus:outline-none';
    if (tabId === activeTab) {
      return `${baseClasses} text-red-400 border-b-2 border-red-400`;
    }
    return `${baseClasses} text-gray-400 hover:text-white border-b-2 border-transparent hover:border-gray-500`;
  };

  return (
    <div className="flex space-x-2 border-b border-gray-700 bg-gray-800 px-6">
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onTabSelect(tab.id as Module | 'all')}
          className={getTabClass(tab.id as Module | 'all')}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};

export default ModuleTabs;
