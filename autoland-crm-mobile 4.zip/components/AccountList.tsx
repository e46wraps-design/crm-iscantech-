import React, { useState, useMemo } from 'react';
import type { Customer } from '../types';
import { Icons } from '../constants';

interface AccountListProps {
  customers: Customer[];
  onSelectCustomer: (customer: Customer) => void;
}

type SortableKeys = keyof Pick<Customer, 'name' | 'company' | 'email'>;

const AccountList: React.FC<AccountListProps> = ({ customers, onSelectCustomer }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'ascending' | 'descending' } | null>({ key: 'name', direction: 'ascending' });

  const filteredCustomers = useMemo(() => {
    if (!searchTerm) {
      return customers;
    }
    const lowercasedTerm = searchTerm.toLowerCase();
    return customers.filter(customer => 
      customer.name.toLowerCase().includes(lowercasedTerm) ||
      customer.company.toLowerCase().includes(lowercasedTerm) ||
      customer.email.toLowerCase().includes(lowercasedTerm)
    );
  }, [customers, searchTerm]);

  const sortedCustomers = useMemo(() => {
    let sortableItems = [...filteredCustomers];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [filteredCustomers, sortConfig]);

  const requestSort = (key: SortableKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortableKeys) => {
      if (!sortConfig || sortConfig.key !== key) return null;
      return sortConfig.direction === 'ascending' ? '▲' : '▼';
  }
  
  const highlightMatch = (text: string, highlight: string) => {
      if (!highlight.trim()) {
          return <>{text}</>;
      }
      const regex = new RegExp(`(${highlight})`, 'gi');
      const parts = text.split(regex);
      return (
          <span>
              {parts.map((part, i) =>
                  part.toLowerCase() === highlight.toLowerCase() ? (
                      <span key={i} className="bg-yellow-500/80 text-black px-0.5 rounded-sm">{part}</span>
                  ) : (
                      part
                  )
              )}
          </span>
      );
  };

  const SortableHeader: React.FC<{ label: string, sortKey: SortableKeys }> = ({ label, sortKey }) => (
    <th
        scope="col"
        className="p-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-700/80 transition"
        onClick={() => requestSort(sortKey)}
    >
        <div className="flex items-center">
            {label}
            <span className="ml-2 text-red-400">{getSortIcon(sortKey)}</span>
        </div>
    </th>
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-end items-center">
        <div className="relative">
          <input
            type="search"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-red-500 w-72"
            aria-label="Search customers by name, company, or email"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            {Icons.search}
          </div>
        </div>
      </div>

      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-700/50">
              <tr>
                <SortableHeader label="Name" sortKey="name" />
                <SortableHeader label="Company" sortKey="company" />
                <SortableHeader label="Email" sortKey="email" />
                <th scope="col" className="p-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Phone</th>
                <th scope="col" className="relative p-4"><span className="sr-only">View Portal</span></th>
              </tr>
            </thead>
            <tbody className="bg-gray-800 divide-y divide-gray-700">
              {sortedCustomers.map(customer => (
                <tr key={customer.id} className="hover:bg-gray-700/50 transition-colors">
                  <td className="p-4 whitespace-nowrap text-sm font-medium text-white">{highlightMatch(customer.name, searchTerm)}</td>
                  <td className="p-4 whitespace-nowrap text-sm text-gray-300">{highlightMatch(customer.company, searchTerm)}</td>
                  <td className="p-4 whitespace-nowrap text-sm text-gray-300">{highlightMatch(customer.email, searchTerm)}</td>
                  <td className="p-4 whitespace-nowrap text-sm text-gray-300">{customer.phone}</td>
                  <td className="p-4 whitespace-nowrap text-right text-sm font-medium">
                    <button 
                      onClick={() => onSelectCustomer(customer)}
                      className="text-red-400 hover:text-red-300 font-semibold"
                    >
                      View Portal &rarr;
                    </button>
                  </td>
                </tr>
              ))}
              {sortedCustomers.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-10 text-gray-500">
                    No customers found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AccountList;
