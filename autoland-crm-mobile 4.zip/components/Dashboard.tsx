import React, { useMemo } from 'react';
import type { Ticket, FilterState, LoanerTool, User } from '../types';
import { Status, Module, LoanerToolStatus } from '../types';
import { Icons, CURRENT_USER } from '../constants';
import type { View } from '../App';

interface DashboardProps {
    tickets: Ticket[];
    users: User[];
    loanerTools: LoanerTool[];
    onSelectTicket: (ticketId: string) => void;
    onNavigate: (view: View, filters?: Partial<FilterState>, module?: Module | 'all') => void;
    onNewCase: () => void;
}

const KpiCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; color: string; onClick?: () => void; }> = ({ title, value, icon, color, onClick }) => (
    <button 
        onClick={onClick}
        disabled={!onClick}
        className={`bg-gray-800/50 border border-gray-700/50 rounded-lg p-4 text-left w-full flex flex-col justify-between h-full ${onClick ? 'hover:bg-gray-700/50 hover:border-gray-600 transition' : 'cursor-default'}`}
    >
        <div className="flex justify-between items-start">
            <div className={`p-2 rounded-lg ${color}`}>
                <div className="w-6 h-6">{icon}</div>
            </div>
        </div>
        <div>
            <div className="text-3xl font-bold text-white mt-2">{value}</div>
            <div className="text-sm text-gray-400 font-semibold">{title}</div>
        </div>
    </button>
);

const QuickActionButton: React.FC<{ title: string; icon: React.ReactNode; onClick: () => void; }> = ({ title, icon, onClick }) => (
    <button onClick={onClick} className="bg-gray-800 border border-gray-700 rounded-lg p-4 flex flex-col items-center justify-center text-center hover:bg-red-900/50 hover:border-red-700 transition-all group">
        <div className="w-8 h-8 text-red-400 group-hover:text-red-300 mb-2">{icon}</div>
        <span className="text-sm font-semibold text-gray-300 group-hover:text-white">{title}</span>
    </button>
);

const TaskItem: React.FC<{ ticket: Ticket; onSelectTicket: (ticketId: string) => void }> = ({ ticket, onSelectTicket }) => {
    const statusColors: { [key: string]: string } = {
        'Callback no voicemail': 'bg-yellow-600/80 text-yellow-100 border-yellow-500/50',
        'Awaiting Reply': 'bg-blue-600/80 text-blue-100 border-blue-500/50',
        'New': 'bg-purple-600/80 text-purple-100 border-purple-500/50',
        'In Progress': 'bg-orange-600/80 text-orange-100 border-orange-500/50',
    };
    const statusColor = statusColors[ticket.status] || 'bg-gray-600 text-gray-100 border-gray-500';

    return (
        <div
            onClick={() => onSelectTicket(ticket.id)}
            className="flex items-center p-3 hover:bg-gray-700/50 rounded-lg cursor-pointer transition-colors"
        >
            <div className="flex-1">
                <p className="text-sm font-semibold text-gray-200 truncate">{ticket.subject}</p>
                <p className="text-xs text-gray-400">{ticket.id} &bull; {ticket.requester}</p>
            </div>
            <span className={`ml-4 text-xs font-semibold px-2 py-0.5 rounded-full border ${statusColor}`}>{ticket.status}</span>
        </div>
    );
};

const ActivityItem: React.FC<{ activity: any; onSelectTicket: (ticketId: string) => void }> = ({ activity, onSelectTicket }) => (
    <div className="flex items-start">
        <img src={activity.user.avatarUrl || `https://i.pravatar.cc/40?u=${activity.user.name}`} alt={activity.user.name} className="w-8 h-8 rounded-full mr-3" />
        <div className="text-sm">
            <p className="text-gray-300">
                <span className="font-bold text-white">{activity.user.name}</span> {activity.actionText} ticket <button onClick={() => onSelectTicket(activity.ticket.id)} className="font-semibold text-red-400 hover:underline">{activity.ticket.id}</button>.
            </p>
            <p className="text-xs text-gray-500 mt-0.5">{activity.timestamp.split('(')[0]}</p>
        </div>
    </div>
);


const Dashboard: React.FC<DashboardProps> = ({ tickets, users, loanerTools, onSelectTicket, onNavigate, onNewCase }) => {
    const stats = useMemo(() => {
        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        
        const myOpenTickets = tickets.filter(t => t.assignee === CURRENT_USER.name && t.status !== Status.CALL_COMPLETED).length;
        const unassigned = tickets.filter(t => !t.assignee && t.status !== Status.CALL_COMPLETED).length;
        const overdue = tickets.filter(t => t.dueDate && new Date(t.dueDate) < now && t.status !== Status.CALL_COMPLETED).length;
        
        const resolvedToday = tickets.filter(t => {
            if (t.status !== Status.CALL_COMPLETED) return false;
            // A simple way to check is to see if it was created today and is now closed.
            // A more complex system would track resolution date.
            const createdAt = new Date(t.createdAt).getTime();
            return createdAt >= todayStart;
        }).length;
        
        const loanerStats = loanerTools.reduce((acc, tool) => {
            acc[tool.status] = (acc[tool.status] || 0) + 1;
            return acc;
        }, {} as Record<LoanerToolStatus, number>);

        return { myOpenTickets, unassigned, overdue, resolvedToday, loanerStats };
    }, [tickets, loanerTools]);

    const myTasks = useMemo(() => {
        return tickets
            .filter(t => t.assignee === CURRENT_USER.name && t.status !== Status.CALL_COMPLETED)
            .sort((a, b) => {
                if (!a.dueDate) return 1;
                if (!b.dueDate) return -1;
                return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
            })
            .slice(0, 7);
    }, [tickets]);

    const teamActivity = useMemo(() => {
        return tickets
            .flatMap(ticket => ticket.updates.map(update => ({ ...update, ticket })))
            .sort((a, b) => {
                try {
                    // Attempt to parse timestamps; use ticket creation as fallback
                    return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
                } catch (e) {
                    return new Date(b.ticket.createdAt).getTime() - new Date(a.ticket.createdAt).getTime();
                }
            })
            .slice(0, 5)
            .map(update => {
                const user = users.find(u => u.name === update.author) || { name: update.author };
                let actionText = 'updated';
                if (update.content.toLowerCase().includes('case created')) actionText = 'created';
                else if (update.ticket.status === Status.CALL_COMPLETED) actionText = 'resolved';
                
                return { user, actionText, ticket: update.ticket, timestamp: update.timestamp };
            });
    }, [tickets, users]);
    
    const getGreeting = () => {
        const hour = new Date().getHours();
        if (hour < 12) return 'Good morning';
        if (hour < 18) return 'Good afternoon';
        return 'Good evening';
    };

    return (
        <div className="space-y-6 p-4 sm:p-6">
            <div>
                <h2 className="text-2xl font-bold text-white">{getGreeting()}, {CURRENT_USER.name.split(' ')[0]}!</h2>
                <p className="text-gray-400">{new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <QuickActionButton title="New Case" icon={Icons.plus} onClick={onNewCase} />
                <QuickActionButton title="New Tool Repair" icon={Icons.settings} onClick={() => onNavigate('cases', {}, Module.TOOL_REPAIR)} />
                <QuickActionButton title="Search Customers" icon={Icons.accounts} onClick={() => onNavigate('accounts')} />
                <QuickActionButton title="Run SOD Report" icon={Icons.reports} onClick={() => onNavigate('reports')} />
            </div>

            <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <KpiCard title="My Open Cases" value={stats.myOpenTickets} icon={Icons.userCircle} color="bg-purple-500/30 text-purple-300" onClick={() => onNavigate('cases', { assignedToMe: true })} />
                        <KpiCard title="Unassigned" value={stats.unassigned} icon={Icons.questionMarkCircle} color="bg-yellow-500/30 text-yellow-300" onClick={() => onNavigate('cases', { statuses: [Status.NEW] })} />
                        <KpiCard title="Overdue" value={stats.overdue} icon={Icons.clock} color="bg-red-500/30 text-red-300" />
                        <KpiCard title="Resolved Today" value={stats.resolvedToday} icon={Icons.checkCircle} color="bg-green-500/30 text-green-300" onClick={() => onNavigate('cases', { statuses: [Status.CALL_COMPLETED] })}/>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-xl font-bold text-white">My Tasks</h2>
                            <button onClick={() => onNavigate('cases', { assignedToMe: true })} className="text-sm font-semibold text-red-400 hover:text-red-300">View All</button>
                        </div>
                        <div className="space-y-2">
                            {myTasks.length > 0 ? (
                                myTasks.map(ticket => (
                                    <TaskItem key={ticket.id} ticket={ticket} onSelectTicket={onSelectTicket} />
                                ))
                            ) : (
                                <p className="text-center py-4 text-gray-500">You have no open tasks.</p>
                            )}
                        </div>
                    </div>
                </div>
                <aside className="space-y-6">
                    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                         <h2 className="text-xl font-bold text-white mb-4">Loaner Tools Status</h2>
                         <div className="space-y-3">
                             {Object.values(LoanerToolStatus).map(status => (
                                <div key={status} className="flex justify-between items-center text-sm">
                                    <span className="text-gray-400">{status}</span>
                                    <span className="font-bold text-white bg-gray-700 px-2 py-0.5 rounded-md">{stats.loanerStats[status] || 0}</span>
                                </div>
                             ))}
                         </div>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
                         <h2 className="text-xl font-bold text-white mb-4">Team Activity</h2>
                         <div className="space-y-4">
                             {teamActivity.map((activity, index) => (
                                <ActivityItem key={index} activity={activity} onSelectTicket={onSelectTicket} />
                             ))}
                         </div>
                    </div>
                </aside>
            </main>
        </div>
    );
};

export default Dashboard;
