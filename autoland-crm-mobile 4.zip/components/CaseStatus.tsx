import React, { useState, useRef, useEffect } from 'react';
import { Status, User } from '../types';
import { STATUSES } from '../constants';

interface CaseStatusProps {
    onSave: (close: boolean) => void;
    status: Status;
    onStatusChange: (status: Status) => void;
    users: User[];
    assignee: string;
    onAssigneeChange: (assignee: string) => void;
}

const SelectInput: React.FC<{ label: string; value?: string; onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void; children: React.ReactNode }> = ({ label, children, value, onChange }) => (
    <div className="flex-1">
        <label className="text-xs font-semibold text-gray-400 mb-1 block">{label}</label>
        <select value={value} onChange={onChange} className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500">
            {children}
        </select>
    </div>
);

// Custom hook to detect clicks outside of a component
function useOutsideAlerter(ref: React.RefObject<any>, callback: () => void) {
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (ref.current && !ref.current.contains(event.target)) {
        callback();
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref, callback]);
}

const AssigneeDropdown: React.FC<{ users: User[], assignee: string, onAssigneeChange: (name: string) => void }> = ({ users, assignee, onAssigneeChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef(null);
    useOutsideAlerter(wrapperRef, () => setIsOpen(false));

    const selectedUser = users.find(u => u.name === assignee);

    const handleSelect = (name: string) => {
        onAssigneeChange(name);
        setIsOpen(false);
    }

    return (
        <div className="relative flex-1" ref={wrapperRef}>
            <label className="text-xs font-semibold text-gray-400 mb-1 block">Assignee</label>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="w-full h-[40px] bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 flex items-center justify-between text-left"
            >
                <div className="flex items-center">
                    {selectedUser && selectedUser.avatarUrl ? (
                        <>
                            <img src={selectedUser.avatarUrl} alt={selectedUser.name} className="w-6 h-6 rounded-full mr-2" />
                            <span className="text-gray-200">{selectedUser.name}</span>
                        </>
                    ) : (
                        <span className="text-gray-400">{assignee || '-- Unassigned --'}</span>
                    )}
                </div>
                 <span className="text-gray-400">{isOpen ? '▲' : '▼'}</span>
            </button>
            {isOpen && (
                <div className="absolute z-10 bottom-full mb-1 w-full bg-gray-700 border border-gray-600 rounded-md shadow-lg max-h-60 overflow-y-auto">
                    <button onClick={() => handleSelect('')} className="w-full text-left flex items-center p-2 text-sm text-gray-400 hover:bg-gray-600">
                         -- Unassigned --
                    </button>
                    {users.map(user => (
                        <button key={user.id} onClick={() => handleSelect(user.name)} className="w-full text-left flex items-center p-2 text-sm text-gray-200 hover:bg-gray-600">
                            {user.avatarUrl && <img src={user.avatarUrl} alt={user.name} className="w-6 h-6 rounded-full mr-2" />}
                            {user.name}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
}

const CaseStatus: React.FC<CaseStatusProps> = ({ onSave, status, onStatusChange, users, assignee, onAssigneeChange }) => {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
        <h3 className="text-lg font-bold mb-4 text-white">Case Status</h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
            <AssigneeDropdown 
                users={users}
                assignee={assignee}
                onAssigneeChange={onAssigneeChange}
            />
            <SelectInput 
                label="Status"
                value={status}
                onChange={(e) => onStatusChange(e.target.value as Status)}
            >
                {STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </SelectInput>
            <SelectInput label="Channel">
                <option>GroupMSG</option>
            </SelectInput>
            <SelectInput label="Department">
                <option>Technical (US)</option>
            </SelectInput>
            <SelectInput label="Alert / Manager">
                <option>--</option>
            </SelectInput>
            <SelectInput label="Software issue">
                <option>--</option>
            </SelectInput>
        </div>
        <div className="flex justify-end space-x-3">
            <button onClick={() => onSave(false)} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded transition">
                Save
            </button>
            <button 
                onClick={() => onSave(true)}
                className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded transition"
            >
                Save & Return
            </button>
        </div>
    </div>
  );
};

export default CaseStatus;