import React from 'react';
import type { Ticket, User } from '../types';
import { Status } from '../types';
import { Icons } from '../constants';

interface TicketListItemProps {
  ticket: Ticket;
  onSelectTicket: (ticketId: string) => void;
  searchTerm: string;
  users: User[];
  onUpdateTicket: (ticket: Ticket) => void;
}

const TicketListItem: React.FC<TicketListItemProps> = ({ ticket, onSelectTicket, searchTerm, users, onUpdateTicket }) => {
  const statusColors: { [key: string]: string } = {
    'Call completed': 'bg-green-600',
    'Callback no voicemail': 'bg-yellow-600',
    'Awaiting Reply': 'bg-blue-600',
    'New': 'bg-purple-600',
  };
  const statusColor = statusColors[ticket.status] || 'bg-gray-600';

  const highlightMatch = (text: string | undefined, highlight: string) => {
      if (!text || !highlight.trim()) {
          return <>{text}</>;
      }
      const regex = new RegExp(`(${highlight})`, 'gi');
      const parts = text.split(regex);
      return (
          <span>
              {parts.map((part, i) =>
                  part.toLowerCase() === highlight.toLowerCase() ? (
                      <span key={i} className="bg-yellow-500/80 text-black px-0.5 rounded-sm">{part}</span>
                  ) : (
                      part
                  )
              )}
          </span>
      );
  };

  const handleQuickAssign = (e: React.ChangeEvent<HTMLSelectElement>) => {
    e.stopPropagation(); // Prevent card click
    const newAssignee = e.target.value;
    if (newAssignee) {
      const updatedTicket: Ticket = {
        ...ticket,
        assignee: newAssignee,
        status: ticket.status === Status.NEW ? Status.IN_PROGRESS : ticket.status, // Optionally update status
        timestamp: new Date().toLocaleString() + ' (assigned)',
      };
      onUpdateTicket(updatedTicket);
    }
  };

  const dueDate = ticket.dueDate ? new Date(ticket.dueDate) : null;
  const isOverdue = dueDate && dueDate < new Date() && ticket.status !== Status.CALL_COMPLETED;

  return (
    <div 
      className="bg-red-900/80 border border-red-700/50 rounded-lg shadow-lg p-4 cursor-pointer hover:border-red-500 transition-all duration-200"
      onClick={() => onSelectTicket(ticket.id)}
    >
      <div className="flex justify-between items-start">
        {/* Main Content */}
        <div className="flex-1">
          <div className="flex items-center space-x-4 mb-2 flex-wrap">
            <span className="text-sm font-bold text-gray-300">{highlightMatch(ticket.id, searchTerm)}</span>
            <span className={`px-2 py-0.5 text-xs font-semibold rounded-full text-white ${statusColor}`}>{ticket.status}</span>
            <span className="text-sm text-gray-400">{ticket.timestamp}</span>
          </div>
          <h3 className="text-lg font-bold text-white mb-2">{highlightMatch(ticket.subject, searchTerm)}</h3>
           <div className="text-sm text-gray-300 flex items-center gap-4 flex-wrap">
            <p>
                From: <span className="font-semibold text-red-300">{highlightMatch(ticket.requester, searchTerm)}</span>
            </p>
            {ticket.assignee ? (
                <div className="flex items-center text-xs text-gray-400 border-l border-red-800/50 pl-4">
                    <div className="w-4 h-4 mr-1.5">{Icons.user}</div>
                    <span>{ticket.assignee}</span>
                </div>
            ) : (
                <div className="flex items-center text-xs text-yellow-400 border-l border-red-800/50 pl-4">
                    <div className="w-4 h-4 mr-1.5">{Icons.questionMarkCircle}</div>
                    <span>Unassigned</span>
                </div>
            )}
            {dueDate && (
                <div className={`flex items-center text-xs border-l border-red-800/50 pl-4 ${isOverdue ? 'text-red-400 font-bold' : 'text-gray-400'}`}>
                    <div className="w-4 h-4 mr-1.5">{Icons.clock}</div>
                    <span>Due: {dueDate.toLocaleDateString()}</span>
                </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2 flex-shrink-0 ml-4">
          {!ticket.assignee ? (
            <div className="flex items-center">
              <select
                onChange={handleQuickAssign}
                onClick={(e) => e.stopPropagation()}
                className="bg-gray-700 hover:bg-gray-600 text-xs font-bold text-white py-1 pl-2 pr-6 rounded transition border border-gray-600 focus:ring-1 focus:ring-red-500"
                defaultValue=""
                aria-label="Quick assign ticket"
              >
                <option value="" disabled>Quick Assign...</option>
                {users.map(user => (
                  <option key={user.id} value={user.name}>{user.name}</option>
                ))}
              </select>
            </div>
          ) : (
            <>
              <button onClick={(e) => { e.stopPropagation(); alert('Not implemented'); }} className="bg-gray-700 hover:bg-gray-600 text-xs font-bold text-white py-1 px-3 rounded transition">Message</button>
              <button onClick={(e) => { e.stopPropagation(); alert('Not implemented'); }} className="bg-gray-700 hover:bg-gray-600 text-xs font-bold text-white py-1 px-3 rounded transition">Merge</button>
              <button onClick={(e) => { e.stopPropagation(); alert('Not implemented'); }} className="bg-gray-700 hover:bg-gray-600 text-xs font-bold text-white py-1 px-3 rounded transition">Close</button>
            </>
          )}
        </div>
      </div>
      
      {/* Details Section */}
      <div className="mt-4 pt-4 border-t border-red-800/50 text-sm space-y-2">
        {ticket.symptom && (
          <div>
            <span className="font-bold text-gray-400">Symptom:</span>
            <p className="text-gray-300 pl-2">{highlightMatch(ticket.symptom, searchTerm)}</p>
          </div>
        )}
        {ticket.response && (
          <div>
            <span className="font-bold text-gray-400">Response:</span>
            <p className="text-gray-300 pl-2">{highlightMatch(ticket.response, searchTerm)}</p>
          </div>
        )}
        {ticket.attachments && (
            <div>
                 <span className="font-bold text-gray-400">Attachments:</span>
                 {ticket.attachments.map((att, index) => (
                    <a key={index} href={att.url} className="text-blue-400 hover:underline ml-2">{att.name}</a>
                 ))}
            </div>
        )}
      </div>
    </div>
  );
};

export default TicketListItem;