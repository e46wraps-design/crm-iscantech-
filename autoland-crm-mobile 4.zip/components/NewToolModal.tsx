
import React, { useState } from 'react';
import type { Tool } from '../types';

interface NewToolModalProps {
    onClose: () => void;
    onAddTool: (newTool: Omit<Tool, 'customerId'>) => void;
    customerId: string;
}

const NewToolModal: React.FC<NewToolModalProps> = ({ onClose, onAddTool, customerId }) => {
    const [model, setModel] = useState('');
    const [serialNumber, setSerialNumber] = useState('');
    const [purchaseDate, setPurchaseDate] = useState('');
    const [warrantyEndDate, setWarrantyEndDate] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!model || !serialNumber || !purchaseDate || !warrantyEndDate) {
            alert('Please fill out all fields.');
            return;
        }
        onAddTool({
            model,
            serialNumber,
            purchaseDate: new Date(purchaseDate).toISOString(),
            warrantyEndDate: new Date(warrantyEndDate).toISOString(),
        });
    }

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex flex-col justify-end sm:items-center sm:justify-center z-50"
            onClick={onClose}
        >
            <div 
                className="bg-gray-800 border-t sm:border border-gray-700 rounded-t-lg sm:rounded-lg shadow-xl p-8 w-full sm:max-w-lg animate-slide-up sm:animate-none"
                onClick={(e) => e.stopPropagation()}
            >
                <form onSubmit={handleSubmit}>
                    <h2 className="text-2xl font-bold text-white mb-6">
                        Register New Tool
                    </h2>
                    
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-1">Tool Model</label>
                            <input 
                                type="text"
                                id="model"
                                value={model}
                                onChange={(e) => setModel(e.target.value)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="serialNumber" className="block text-sm font-medium text-gray-300 mb-1">Serial Number</label>
                            <input 
                                type="text"
                                id="serialNumber"
                                value={serialNumber}
                                onChange={(e) => setSerialNumber(e.target.value)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                required
                            />
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                             <div>
                                <label htmlFor="purchaseDate" className="block text-sm font-medium text-gray-300 mb-1">Purchase Date</label>
                                <input 
                                    type="date"
                                    id="purchaseDate"
                                    value={purchaseDate}
                                    onChange={(e) => setPurchaseDate(e.target.value)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="warrantyEndDate" className="block text-sm font-medium text-gray-300 mb-1">Warranty End Date</label>
                                <input 
                                    type="date"
                                    id="warrantyEndDate"
                                    value={warrantyEndDate}
                                    onChange={(e) => setWarrantyEndDate(e.target.value)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
                                    required
                                />
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-4 mt-8">
                        <button type="button" onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded transition">
                            Cancel
                        </button>
                        <button type="submit" className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded transition">
                            Add Tool
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default NewToolModal;
