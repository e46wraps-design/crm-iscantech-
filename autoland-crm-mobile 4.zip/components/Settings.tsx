import React, { useState, useEffect, useRef } from 'react';
import { PREDEFINED_SOUNDS, CURRENT_USER } from '../constants';
import type { Sound, User } from '../types';

const SOUND_SETTINGS_KEY = 'autoland-crm-sound-settings';
const SAML_SETTINGS_KEY = 'autoland-crm-saml-settings';

interface SamlConfig {
  entityId: string;
  ssoUrl: string;
  certificate: string;
  status: 'not_configured' | 'configured' | 'connected';
}

// Extract SamlStatusPill to a separate component for better organization and memoization
const SamlStatusPill: React.FC<{ status: SamlConfig['status'] }> = React.memo(({ status }) => {
  const statusMap = {
    not_configured: { text: 'Not Configured', color: 'bg-gray-500' },
    configured: { text: 'Configured', color: 'bg-yellow-500/80 text-yellow-900' },
    connected: { text: 'Connected', color: 'bg-green-500/80 text-green-100' },
  };
  const currentStatus = statusMap[status];
  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${currentStatus.color}`}
      role="status"
      aria-label={`SAML status: ${currentStatus.text}`}
    >
      {currentStatus.text}
    </span>
  );
});

const Settings: React.FC<{ users: User[]; onUpdateUser: (user: User) => void }> = ({ users, onUpdateUser }) => {
  const [selectedSound, setSelectedSound] = useState<Sound | null>(null);
  const [customSoundName, setCustomSoundName] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [samlConfig, setSamlConfig] = useState<SamlConfig>({
    entityId: '',
    ssoUrl: '',
    certificate: '',
    status: 'not_configured',
  });
  const [isSavingSaml, setIsSavingSaml] = useState(false);
  const [isTestingSaml, setIsTestingSaml] = useState(false);

  useEffect(() => {
    // Load sound settings
    try {
      const savedSettings = localStorage.getItem(SOUND_SETTINGS_KEY);
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings) as Sound;
        if (parsed && typeof parsed === 'object' && 'name' in parsed && 'url' in parsed) {
          setSelectedSound(parsed);
          if (parsed.name === 'Custom') {
            setCustomSoundName('custom_sound.mp3');
          }
        } else {
          setSelectedSound(PREDEFINED_SOUNDS[0]);
        }
      } else {
        setSelectedSound(PREDEFINED_SOUNDS[0]);
      }
    } catch (error) {
      console.error('Failed to load sound settings', error);
      setSelectedSound(PREDEFINED_SOUNDS[0]);
    }

    // Load SAML settings
    try {
      const savedSamlSettings = localStorage.getItem(SAML_SETTINGS_KEY);
      if (savedSamlSettings) {
        const parsed = JSON.parse(savedSamlSettings) as SamlConfig;
        if (
          parsed &&
          typeof parsed === 'object' &&
          'entityId' in parsed &&
          'ssoUrl' in parsed &&
          'certificate' in parsed &&
          'status' in parsed
        ) {
          setSamlConfig(parsed);
        }
      }
    } catch (error) {
      console.error('Failed to load SAML settings', error);
    }
  }, []);

  const saveSoundSettings = (sound: Sound) => {
    try {
      localStorage.setItem(SOUND_SETTINGS_KEY, JSON.stringify(sound));
      setSelectedSound(sound);
    } catch (error) {
      console.error('Failed to save sound settings', error);
    }
  };

  const handleSoundChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const soundName = e.target.value;
    const sound = PREDEFINED_SOUNDS.find((s) => s.name === soundName);
    if (sound) {
      saveSoundSettings(sound);
      if (customSoundName) setCustomSoundName(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'audio/mpeg') {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const customSound: Sound = {
            name: 'Custom',
            url: event.target.result as string,
          };
          saveSoundSettings(customSound);
          setCustomSoundName(file.name);
        }
      };
      reader.onerror = () => alert('Error reading the uploaded file.');
      reader.readAsDataURL(file);
    } else {
      alert('Please upload a valid MP3 file.');
    }
  };

  const playPreview = () => {
    if (selectedSound?.url && audioRef.current) {
      audioRef.current.src = selectedSound.url;
      audioRef.current
        .play()
        .catch((e) => console.error('Error playing preview:', e));
    }
  };

  const handleSamlChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setSamlConfig((prev) => ({ ...prev, [name]: value, status: 'configured' }));
  };

  const handleSaveSaml = () => {
    setIsSavingSaml(true);
    try {
      console.log('Saving SAML configuration:', samlConfig);
      localStorage.setItem(SAML_SETTINGS_KEY, JSON.stringify(samlConfig));
    } catch (error) {
      console.error('Failed to save SAML settings', error);
    }
    setTimeout(() => {
      setIsSavingSaml(false);
    }, 1500);
  };

  const handleTestSaml = () => {
    setIsTestingSaml(true);
    console.log('Testing SAML connection with:', samlConfig);
    setTimeout(() => {
      const isSuccess = Math.random() > 0.2; // 80% success rate for demo
      if (isSuccess) {
        setSamlConfig((prev) => ({ ...prev, status: 'connected' }));
      } else {
        alert('Simulated connection test failed. Please check your configuration and try again.');
      }
      setIsTestingSaml(false);
    }, 2000);
  };

  const handleRoleChange = (userId: string, newRole: 'admin' | 'tech') => {
    const userToUpdate = users.find(u => u.id === userId);
    if (userToUpdate) {
        onUpdateUser({ ...userToUpdate, role: newRole });
    }
  };

  if (!selectedSound) {
    return (
      <div className="p-6 text-center" role="alert">
        Loading settings...
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
        <h2 className="text-xl font-bold text-white mb-4">Notification Sounds</h2>
        <div className="space-y-4 max-w-md">
          <div>
            <label
              htmlFor="sound-select"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              New Ticket Sound
            </label>
            <select
              id="sound-select"
              value={selectedSound.name}
              onChange={handleSoundChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
              aria-describedby="sound-select-description"
            >
              {PREDEFINED_SOUNDS.map((sound) => (
                <option key={sound.name} value={sound.name}>
                  {sound.name}
                </option>
              ))}
              {selectedSound.name === 'Custom' && (
                <option value="Custom">{`Custom (${customSoundName || 'uploaded file'})`}</option>
              )}
            </select>
            <p id="sound-select-description" className="text-xs text-gray-400 mt-1">
              Select a predefined sound or upload a custom MP3.
            </p>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded transition text-sm"
              aria-label="Upload custom MP3"
            >
              Upload Custom MP3
            </button>
            <input
              type="file"
              accept="audio/mpeg"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              aria-label="Upload custom MP3 sound"
            />
            <button
              onClick={playPreview}
              className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition text-sm disabled:opacity-50"
              disabled={!selectedSound.url}
              aria-label="Preview selected sound"
            >
              Preview Sound
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
        <h2 className="text-xl font-bold text-white mb-4">User Management</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Email</th>
                <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Role</th>
              </tr>
            </thead>
            <tbody className="bg-gray-800 divide-y divide-gray-700">
              {users.map(user => (
                <tr key={user.id}>
                  <td className="p-3 text-sm font-medium text-white flex items-center">
                    {user.avatarUrl && <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full mr-3" />}
                    {user.name}
                  </td>
                  <td className="p-3 text-sm text-gray-300">{user.email}</td>
                  <td className="p-3 text-sm">
                    <select
                      value={user.role}
                      onChange={(e) => handleRoleChange(user.id, e.target.value as 'admin' | 'tech')}
                      disabled={user.id === CURRENT_USER.id} // Prevent admin from changing their own role
                      className="bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      aria-label={`Role for ${user.name}`}
                    >
                      <option value="tech">Tech</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Zoho Sync - SAML Authentication</h2>
          <SamlStatusPill status={samlConfig.status} />
        </div>
        <div className="space-y-4">
          <div>
            <label
              htmlFor="entityId"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              Issuer / Entity ID
            </label>
            <input
              type="text"
              id="entityId"
              name="entityId"
              value={samlConfig.entityId}
              onChange={handleSamlChange}
              placeholder="e.g., https://your-idp.com/saml2"
              className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
              aria-describedby="entityId-description"
            />
            <p id="entityId-description" className="text-xs text-gray-400 mt-1">
              Enter the SAML Issuer or Entity ID provided by your identity provider.
            </p>
          </div>
          <div>
            <label
              htmlFor="ssoUrl"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              SAML 2.0 Endpoint (URL)
            </label>
            <input
              type="url"
              id="ssoUrl"
              name="ssoUrl"
              value={samlConfig.ssoUrl}
              onChange={handleSamlChange}
              placeholder="e.g., https://your-idp.com/saml2/sso"
              className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500"
              aria-describedby="ssoUrl-description"
            />
            <p id="ssoUrl-description" className="text-xs text-gray-400 mt-1">
              Enter the SAML 2.0 SSO endpoint URL.
            </p>
          </div>
          <div>
            <label
              htmlFor="certificate"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              X.509 Certificate
            </label>
            <textarea
              id="certificate"
              name="certificate"
              value={samlConfig.certificate}
              onChange={handleSamlChange}
              rows={8}
              placeholder="-----BEGIN CERTIFICATE----- ... -----END CERTIFICATE-----"
              className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-sm font-mono focus:ring-red-500 focus:border-red-500 resize-y"
              aria-describedby="certificate-description"
            />
            <p id="certificate-description" className="text-xs text-gray-400 mt-1">
              Paste the X.509 certificate for SAML authentication.
            </p>
          </div>
          <div className="flex justify-end items-center space-x-4">
            <button
              onClick={handleTestSaml}
              className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded transition text-sm disabled:opacity-50 disabled:cursor-wait"
              disabled={
                isTestingSaml ||
                !samlConfig.entityId ||
                !samlConfig.ssoUrl ||
                !samlConfig.certificate
              }
              aria-label="Test SAML connection"
            >
              {isTestingSaml ? 'Testing...' : 'Test Connection'}
            </button>
            <button
              onClick={handleSaveSaml}
              className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition text-sm disabled:bg-green-600 disabled:cursor-not-allowed"
              disabled={isSavingSaml}
              aria-label="Save SAML configuration"
            >
              {isSavingSaml ? 'Saved!' : 'Save Configuration'}
            </button>
          </div>
        </div>
      </div>

      <audio ref={audioRef} className="hidden" aria-hidden="true" />
    </div>
  );
};

export default Settings;